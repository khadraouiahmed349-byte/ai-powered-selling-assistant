# ReList AI — Used Product Selling Assistant

Next.js + PostgreSQL + Drizzle application for creating used-item listings.

## Production setup

1. Provision PostgreSQL and set `DATABASE_URL`.
2. Generate a strong `AUTH_SECRET` (32+ random characters).
3. Set `OPENAI_API_KEY`. The app uses the OpenAI Responses API for real vision, listing copy and price estimation; without a key it falls back to the deterministic demo engine.
4. Run the SQL in `drizzle/0000_initial.sql` (or generate/apply migrations with Drizzle Kit).
5. For external images, configure Supabase Storage variables and replace the current client data-URL persistence with the storage endpoint before accepting large production traffic.
6. Set `NEXT_PUBLIC_APP_URL` to the deployed URL.

## Checks

```bash
npm install
npm run typecheck
npm run build
```

The included archive was inspected in this environment. Dependency installation could not complete within the execution window, so a clean `typecheck/build` pass could not be truthfully claimed here.

### Supabase Storage

Create a Storage bucket named `listing-images` and make it public if you want the generated public URLs used by this starter to render directly. Keep `SUPABASE_SERVICE_ROLE_KEY` server-only; never expose it as `NEXT_PUBLIC_*`.
