import { NextResponse } from "next/server";
import { analyzePhoto, generateListing, estimatePrice, qualityScore, optimizeForMarketplace, negotiateReply } from "@/lib/ai";
import { openAIJson } from "@/lib/openai";
import { getSessionUserId } from "@/lib/auth";
import { clientKey, rateLimit } from "@/lib/rate-limit";
import { imageDataUrl, integer, text } from "@/lib/validation";
import { consumeAiCredit } from "@/lib/billing";

const analysisSchema = {
  type: "object", additionalProperties: false,
  properties: {
    product: { type: "string" }, brand: { type: "string" }, category: { type: "string" },
    confidence: { type: "number" }, detectedCondition: { type: "string" }, titleDraft: { type: "string" },
    tags: { type: "array", items: { type: "string" } }, specs: { type: "array", items: { type: "string" } },
    photoTips: { type: "array", items: { type: "string" } },
  }, required: ["product","brand","category","confidence","detectedCondition","titleDraft","tags","specs","photoTips"]
};

const listingSchema = {
  type: "object", additionalProperties: false,
  properties: { title: { type: "string" }, description: { type: "string" }, keywords: { type: "array", items: { type: "string" } } },
  required: ["title","description","keywords"]
};

const priceSchema = {
  type: "object", additionalProperties: false,
  properties: { low: { type: "integer" }, high: { type: "integer" }, suggested: { type: "integer" }, sellFast: { type: "integer" }, confidence: { type: "number" }, reasoning: { type: "array", items: { type: "string" } } },
  required: ["low","high","suggested","sellFast","confidence","reasoning"]
};

function limited(req: Request, suffix: string, limit: number) {
  const r = rateLimit(clientKey(req, suffix), limit, 60_000);
  return r.ok ? null : NextResponse.json({ error: "Too many requests. Try again shortly.", retryAfter: r.retryAfter }, { status: 429 });
}

export async function POST(req: Request) {
  const userId = await getSessionUserId();
  if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const blocked = limited(req, "ai", 20);
  if (blocked) return blocked;
  const credit = await consumeAiCredit(userId);
  if (!credit.allowed) return NextResponse.json({ error: "Monthly AI limit reached.", code: "AI_LIMIT_REACHED", usage: credit }, { status: 402 });

  try {
    const body = await req.json();
    const action = text(body.action, 30);
    const images = Array.isArray(body.images) ? body.images.map(imageDataUrl).filter(Boolean).slice(0, 8) as string[] : [];

    if (action === "analyze") {
      if (process.env.OPENAI_API_KEY && images.length) {
        const result = await openAIJson({
          schemaName: "product_analysis", schema: analysisSchema,
          images: images.map(url => ({ url, detail: "auto" })),
          prompt: `Analyze these actual used-product photos. Do not invent exact model/specs when not visible; use uncertainty. User hint: ${text(body.hint, 500)}. Category hint: ${text(body.category, 100)}. Return practical marketplace data. Confidence must reflect visual certainty.`,
        });
        return NextResponse.json({ result, provider: "openai" });
      }
      const result = analyzePhoto({ fileName: text(body.fileName, 200), hint: text(body.hint, 500), category: text(body.category, 100), imageCount: images.length || integer(body.imageCount, 0, 8) || 0 });
      return NextResponse.json({ result, provider: "heuristic-fallback" });
    }

    if (action === "generate") {
      if (process.env.OPENAI_API_KEY) {
        const result = await openAIJson({
          schemaName: "listing_copy", schema: listingSchema,
          prompt: `Write a truthful used-item marketplace listing. Never invent specs, accessories, condition, warranty, ownership history, or measurements. Product: ${text(body.productHint ?? body.hint, 500)}. Category: ${text(body.category, 100)}. Brand: ${text(body.brand, 100)}. Condition: ${text(body.condition, 50)}. Extra facts from seller: ${text(body.extras, 1500)}. Marketplace: ${text(body.marketplace, 50)}.`,
        });
        return NextResponse.json({ result, provider: "openai" });
      }
      return NextResponse.json({ result: generateListing({ productHint: text(body.productHint ?? body.hint, 500), category: text(body.category, 100), condition: text(body.condition, 50), brand: text(body.brand, 100), extras: text(body.extras, 1500), marketplace: text(body.marketplace, 50) }), provider: "heuristic-fallback" });
    }

    if (action === "estimate") {
      if (process.env.OPENAI_API_KEY) {
        const result = await openAIJson({
          schemaName: "price_estimate", schema: priceSchema,
          prompt: `Estimate a reasonable used-market asking price in ${text(body.currency, 10, "USD")}. Do not claim live market data. Use the seller's original price if provided and explain uncertainty. Product: ${text(body.hint, 500)}. Category: ${text(body.category, 100)}. Condition: ${text(body.condition, 50)}. Original price cents: ${integer(body.originalPriceCents, 0, 100000000) ?? 0}.`,
        });
        return NextResponse.json({ result, provider: "openai" });
      }
      return NextResponse.json({ result: estimatePrice({ category: text(body.category, 100), condition: text(body.condition, 50), originalPriceCents: integer(body.originalPriceCents, 0, 100000000), hint: text(body.hint, 500) }), provider: "heuristic-fallback" });
    }

    if (action === "score") return NextResponse.json({ result: qualityScore({ title: text(body.title, 200), description: text(body.description, 5000), priceCents: integer(body.priceCents, 0, 100000000) ?? 0, imageCount: integer(body.imageCount, 0, 8) ?? 0, category: text(body.category, 100), brand: text(body.brand, 100), condition: text(body.condition, 50), keywords: Array.isArray(body.keywords) ? body.keywords.map((x: unknown) => text(x, 80)).filter(Boolean) : [] }) });
    if (action === "optimize") return NextResponse.json({ result: optimizeForMarketplace(text(body.marketplace ?? "facebook", 50), { title: text(body.title, 200), description: text(body.description, 5000), priceCents: integer(body.priceCents, 0, 100000000) ?? 0, imageCount: integer(body.imageCount, 0, 8) ?? 0 }) });
    if (action === "negotiate") return NextResponse.json({ result: negotiateReply({ buyerMessage: text(body.buyerMessage, 2000), askingCents: integer(body.askingCents, 0, 100000000) ?? 0, offerCents: integer(body.offerCents, 0, 100000000), tone: text(body.tone, 50), listingTitle: text(body.listingTitle, 200) }) });
    return NextResponse.json({ error: "Unknown action." }, { status: 400 });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: e instanceof Error ? e.message : "AI request failed." }, { status: 500 });
  }
}
