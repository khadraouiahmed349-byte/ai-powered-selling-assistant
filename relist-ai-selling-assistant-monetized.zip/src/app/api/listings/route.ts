import { NextResponse } from "next/server";
import { db } from "@/db";
import { listings, listingImages } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { getSessionUserId } from "@/lib/auth";
import { qualityScore } from "@/lib/ai";

export async function GET(req: Request) {
  const userId = await getSessionUserId();
  if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { searchParams } = new URL(req.url);
  const status = searchParams.get("status");
  const q = searchParams.get("q")?.toLowerCase() ?? "";

  let rows = await db.select().from(listings).where(eq(listings.userId, userId)).orderBy(desc(listings.updatedAt));
  if (status && status !== "all") rows = rows.filter((r) => r.status === status);
  if (q) rows = rows.filter((r) => (r.title + " " + r.description + " " + r.category + " " + r.brand).toLowerCase().includes(q));

  // attach images
  const withImages = await Promise.all(
    rows.map(async (l) => {
      const imgs = await db.select().from(listingImages).where(eq(listingImages.listingId, l.id));
      imgs.sort((a, b) => (a.sortOrder - b.sortOrder) || (a.isPrimary ? -1 : 1));
      return { ...l, images: imgs };
    })
  );
  return NextResponse.json({ listings: withImages });
}

export async function POST(req: Request) {
  const userId = await getSessionUserId();
  if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  try {
    const body = await req.json();
    const {
      title, description = "", category = "Other", brand = "", condition = "Good",
      price = 0, originalPrice = null, estimatedLow = null, estimatedHigh = null,
      suggestedPrice = null, status = "draft", marketplaceTargets = [],
      seoKeywords = [], aiAnalysis = {}, images = [] as string[],
    } = body;
    if (!title?.trim()) return NextResponse.json({ error: "Title is required." }, { status: 400 });

    const qs = qualityScore({
      title: title.trim(), description, priceCents: price, imageCount: images.length,
      category, brand, condition, keywords: seoKeywords,
    });

    const [row] = await db.insert(listings).values({
      userId,
      title: title.trim(),
      description,
      category, brand, condition,
      price: Math.round(price) || 0,
      originalPrice: originalPrice ? Math.round(originalPrice) : null,
      estimatedLow, estimatedHigh, suggestedPrice,
      status, qualityScore: qs.score,
      marketplaceTargets, seoKeywords, aiAnalysis,
    }).returning();

    for (let i = 0; i < images.length; i++) {
      if (!images[i]) continue;
      await db.insert(listingImages).values({
        listingId: row.id,
        url: images[i],
        isPrimary: i === 0,
        sortOrder: i,
      });
    }
    const imgs = await db.select().from(listingImages).where(eq(listingImages.listingId, row.id));
    return NextResponse.json({ listing: { ...row, images: imgs } }, { status: 201 });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "Failed to create listing." }, { status: 500 });
  }
}
