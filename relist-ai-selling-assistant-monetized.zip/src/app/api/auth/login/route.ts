import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { verifyPassword, createSession } from "@/lib/auth";
import { ensureSeeded, DEMO_EMAIL } from "@/lib/seed";
import { clientKey, rateLimit } from "@/lib/rate-limit";
import { email, text } from "@/lib/validation";

export async function POST(req: Request) {
  const rl = rateLimit(clientKey(req, "login"), 10, 60_000);
  if (!rl.ok) return NextResponse.json({ error: "Too many login attempts." }, { status: 429 });
  try {
    const body = await req.json();
    const normalizedEmail = email(body.email); const password = typeof body.password === "string" ? body.password : "";
    if (!normalizedEmail || !password) {
      return NextResponse.json({ error: "Email and password are required." }, { status: 400 });
    }
    // Auto-seed demo account so first load feels alive
    if (normalizedEmail === DEMO_EMAIL) {
      try { await ensureSeeded(); } catch (e) { console.error("seed failed", e); }
    }
    const rows = await db.select().from(users).where(eq(users.email, normalizedEmail)).limit(1);
    const user = rows[0];
    if (!user || !(await verifyPassword(password, user.passwordHash))) {
      return NextResponse.json({ error: "Invalid email or password." }, { status: 401 });
    }
    await createSession(user.id);
    const { passwordHash: _p, ...safe } = user;
    return NextResponse.json({ user: safe });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "Login failed. Try again." }, { status: 500 });
  }
}
