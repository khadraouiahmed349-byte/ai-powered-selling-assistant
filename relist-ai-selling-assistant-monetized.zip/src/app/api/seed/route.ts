import { NextResponse } from "next/server";
import { ensureSeeded } from "@/lib/seed";

export async function GET() {
  try {
    const r = await ensureSeeded();
    return NextResponse.json({ ok: true, ...r });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "Seed failed" }, { status: 500 });
  }
}

export async function POST() {
  try {
    const r = await ensureSeeded();
    return NextResponse.json({ ok: true, ...r });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "Seed failed" }, { status: 500 });
  }
}
