"use client";
import { useState } from "react";
import { Calculator, Loader2, Sparkles, TrendingUp } from "lucide-react";
import { Card, SectionTitle } from "@/components/ui";
import CopyButton from "@/components/CopyButton";
import { CATEGORIES, CONDITIONS, formatMoney } from "@/lib/utils";

export default function EstimatorPage() {
  const [hint, setHint] = useState("iPhone 13 128GB");
  const [category, setCategory] = useState("Phones");
  const [condition, setCondition] = useState("Good");
  const [original, setOriginal] = useState("799");
  const [result, setResult] = useState<{ low: number; high: number; suggested: number; sellFast: number; reasoning: string[]; confidence: number } | null>(null);
  const [loading, setLoading] = useState(false);

  const run = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/ai", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "estimate", category, condition,
          originalPriceCents: original ? Math.round(parseFloat(original) * 100) : null, hint,
        }),
      });
      const data = await res.json();
      setResult(data.result);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mx-auto max-w-3xl space-y-6 animate-fadeUp">
      <SectionTitle
        eyebrow="Smart pricing"
        title="Price Estimator"
        desc="Get a data-backed price range for any used item in seconds"
      />
      <Card className="p-5 sm:p-6">
        <label className="text-xs font-bold text-slate-700">What are you selling?</label>
        <input value={hint} onChange={(e) => setHint(e.target.value)} placeholder="e.g. MacBook Air M1, Dyson V11, Trek bike…"
          className="mt-1.5 w-full rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100" />
        <div className="mt-3 grid gap-3 sm:grid-cols-3">
          <div>
            <label className="text-xs font-bold text-slate-500">Category</label>
            <select value={category} onChange={(e) => setCategory(e.target.value)} className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm outline-none focus:border-emerald-500">
              {CATEGORIES.map((c) => <option key={c}>{c}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs font-bold text-slate-500">Condition</label>
            <select value={condition} onChange={(e) => setCondition(e.target.value)} className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm outline-none focus:border-emerald-500">
              {CONDITIONS.map((c) => <option key={c}>{c}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs font-bold text-slate-500">Retail new ($)</label>
            <input type="number" value={original} onChange={(e) => setOriginal(e.target.value)} className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm outline-none focus:border-emerald-500" />
          </div>
        </div>
        <button onClick={run} disabled={loading || !hint.trim()}
          className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 px-4 py-3.5 text-sm font-bold text-white shadow-lg hover:opacity-95 disabled:opacity-50">
          {loading ? <Loader2 size={17} className="animate-spin" /> : <Calculator size={17} />}
          {loading ? "Crunching market data…" : "Estimate my price"}
        </button>

        {result && (
          <div className="mt-5 animate-fadeUp">
            <div className="grid grid-cols-3 gap-2.5 text-center">
              <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                <p className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Fair range</p>
                <p className="mt-1 text-lg font-extrabold sm:text-xl">{formatMoney(result.low)}–{formatMoney(result.high)}</p>
              </div>
              <div className="rounded-2xl bg-gradient-to-br from-emerald-600 to-teal-600 p-4 text-white shadow-xl shadow-emerald-600/25">
                <p className="flex items-center justify-center gap-1 text-[10px] font-bold uppercase tracking-wider text-emerald-100"><Sparkles size={11} /> Suggested</p>
                <p className="mt-1 text-lg font-extrabold sm:text-xl">{formatMoney(result.suggested)}</p>
              </div>
              <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                <p className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Sell in 48h</p>
                <p className="mt-1 text-lg font-extrabold sm:text-xl">{formatMoney(result.sellFast)}</p>
              </div>
            </div>
            <div className="mt-3 rounded-2xl bg-slate-50 p-4">
              <p className="flex items-center gap-1.5 text-xs font-bold"><TrendingUp size={14} className="text-emerald-600" /> WHY THIS PRICE · {result.confidence}% confidence</p>
              <ul className="mt-2 space-y-1.5">
                {result.reasoning.map((r, i) => <li key={i} className="text-[13px] leading-relaxed text-slate-600">• {r}</li>)}
              </ul>
              <div className="mt-3">
                <CopyButton small text={`Price analysis for ${hint} (${condition}): Fair range ${formatMoney(result.low)}–${formatMoney(result.high)}, suggested ${formatMoney(result.suggested)}, quick-sale ${formatMoney(result.sellFast)}.`} label="Copy price analysis" />
              </div>
            </div>
            <div className="mt-3 grid gap-2 rounded-2xl border border-dashed border-slate-300 p-4 text-xs text-slate-500 sm:grid-cols-3">
              <p><b className="text-slate-700">💰 Profit tip:</b> price 8–10% above your minimum — buyers love “winning” a small discount.</p>
              <p><b className="text-slate-700">⚡ Speed tip:</b> the 48h price typically gets 5x more messages in day one.</p>
              <p><b className="text-slate-700">🛡️ Safety tip:</b> never drop below 60% of suggested — it signals desperation.</p>
            </div>
          </div>
        )}
      </Card>
    </div>
  );
}
