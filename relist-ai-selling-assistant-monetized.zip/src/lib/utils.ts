export function cn(...parts: Array<string | false | null | undefined>) {
  return parts.filter(Boolean).join(" ");
}

export function formatMoney(cents: number | null | undefined, currency = "$") {
  if (cents == null) return "—";
  return `${currency}${(cents / 100).toLocaleString("en-US", { maximumFractionDigits: 2, minimumFractionDigits: cents % 100 === 0 ? 0 : 2 })}`;
}

export function timeAgo(date: string | Date) {
  const d = new Date(date);
  const diff = Date.now() - d.getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${days}d ago`;
  return d.toLocaleDateString();
}

export const CATEGORIES = [
  "Phones",
  "Laptops & Computers",
  "Audio",
  "Cameras",
  "Gaming",
  "Home & Furniture",
  "Fashion",
  "Bikes & Scooters",
  "Appliances",
  "Sports",
  "Toys & Kids",
  "Cars & Parts",
  "Other",
];

export const CONDITIONS = ["Like New", "Excellent", "Good", "Fair", "For Parts"] as const;

export const MARKETPLACES = [
  { id: "ebay", name: "eBay", fee: "13.25%", tip: "Use all 80 title chars + item specifics" },
  { id: "facebook", name: "Facebook Marketplace", fee: "5% + ship", tip: "First photo = white background, price in title" },
  { id: "craigslist", name: "Craigslist", fee: "Free–$5", tip: "Short punchy title + cross streets area" },
  { id: "amazon", name: "Amazon Renewed", fee: "~15%", tip: "Condition notes are mandatory" },
  { id: "noon", name: "noon", fee: "~8–15%", tip: "Arabic + English title doubles reach" },
  { id: "opensooq", name: "OpenSooq", fee: "Free / Featured", tip: "Call-to-action in first line" },
  { id: "dubizzle", name: "dubizzle", fee: "Free / Featured", tip: "Verified badge boosts trust 3x" },
  { id: "depop", name: "Depop / Vinted", fee: "10%", tip: "Lifestyle photos outperform plain ones" },
];

export const STATUS_META: Record<string, { label: string; classes: string; dot: string }> = {
  draft: { label: "Draft", classes: "bg-slate-100 text-slate-700 ring-slate-200", dot: "bg-slate-400" },
  active: { label: "Active", classes: "bg-emerald-50 text-emerald-700 ring-emerald-200", dot: "bg-emerald-500" },
  sold: { label: "Sold", classes: "bg-violet-50 text-violet-700 ring-violet-200", dot: "bg-violet-500" },
  archived: { label: "Archived", classes: "bg-amber-50 text-amber-700 ring-amber-200", dot: "bg-amber-500" },
};

export function scoreColor(score: number) {
  if (score >= 80) return { bar: "bg-emerald-500", text: "text-emerald-600", label: "Excellent" };
  if (score >= 60) return { bar: "bg-lime-500", text: "text-lime-600", label: "Good" };
  if (score >= 40) return { bar: "bg-amber-500", text: "text-amber-600", label: "Needs work" };
  return { bar: "bg-rose-500", text: "text-rose-600", label: "Poor" };
}

export async function copyToClipboard(text: string) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    const ta = document.createElement("textarea");
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    try {
      document.execCommand("copy");
      return true;
    } catch {
      return false;
    } finally {
      document.body.removeChild(ta);
    }
  }
}
