import { db } from "@/db";
import { aiUsage, users } from "@/db/schema";
import { eq, and } from "drizzle-orm";

export const FREE_AI_LIMIT = 10;
export const PRO_AI_LIMIT = 200;

export function currentBillingMonth() {
  return new Date().toISOString().slice(0, 7);
}

export async function getPlanUsage(userId: string) {
  const user = (await db.select({ plan: users.plan, subscriptionStatus: users.subscriptionStatus }).from(users).where(eq(users.id, userId)).limit(1))[0];
  const month = currentBillingMonth();
  const usage = (await db.select().from(aiUsage).where(and(eq(aiUsage.userId, userId), eq(aiUsage.month, month))).limit(1))[0];
  const limit = user?.plan === "pro" && user.subscriptionStatus === "active" ? PRO_AI_LIMIT : FREE_AI_LIMIT;
  return { plan: user?.plan ?? "free", status: user?.subscriptionStatus ?? "inactive", used: usage?.count ?? 0, limit, remaining: Math.max(0, limit - (usage?.count ?? 0)), month };
}

export async function consumeAiCredit(userId: string) {
  const usage = await getPlanUsage(userId);
  if (usage.used >= usage.limit) return { allowed: false, ...usage };
  const existing = (await db.select().from(aiUsage).where(and(eq(aiUsage.userId, userId), eq(aiUsage.month, usage.month))).limit(1))[0];
  if (existing) await db.update(aiUsage).set({ count: existing.count + 1 }).where(eq(aiUsage.id, existing.id));
  else await db.insert(aiUsage).values({ userId, month: usage.month, count: 1 });
  return { allowed: true, ...usage, used: usage.used + 1, remaining: usage.remaining - 1 };
}
