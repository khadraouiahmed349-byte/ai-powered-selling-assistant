export function text(value: unknown, max: number, fallback = "") {
  if (typeof value !== "string") return fallback;
  return value.trim().slice(0, max);
}

export function email(value: unknown) {
  const v = text(value, 254).toLowerCase();
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) ? v : null;
}

export function integer(value: unknown, min = 0, max = Number.MAX_SAFE_INTEGER) {
  const n = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(n) || !Number.isInteger(n) || n < min || n > max) return null;
  return n;
}

export function imageDataUrl(value: unknown) {
  if (typeof value !== "string") return null;
  if (/^data:image\/(jpeg|jpg|png|webp);base64,[a-z0-9+/=]+$/i.test(value)) return value.length <= 8_000_000 ? value : null;
  try {
    const url = new URL(value);
    return url.protocol === "https:" && url.href.length <= 2_000 ? url.href : null;
  } catch { return null; }
}
