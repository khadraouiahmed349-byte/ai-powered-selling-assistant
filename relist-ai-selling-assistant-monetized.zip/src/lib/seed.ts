import { db } from "@/db";
import { users, listings, listingImages, negotiations } from "@/db/schema";
import { eq } from "drizzle-orm";
import { hashPassword } from "./auth";

export const DEMO_EMAIL = "demo@relist.ai";
export const DEMO_PASSWORD = "demo1234";

type SeedListing = {
  title: string; description: string; category: string; brand: string;
  condition: string; price: number; originalPrice?: number; status: string;
  qualityScore: number; marketplaces: string[]; keywords: string[];
  images: string[]; views: number; inquiries: number;
};

const SEED_LISTINGS: SeedListing[] = [
  {
    title: "Apple iPhone 13 128GB Midnight — Unlocked, Battery 89%",
    description: "✅ FOR SALE: Apple iPhone 13 128GB\n\nCondition: Excellent — minimal signs of use, fully tested. Battery health 89%, Face ID perfect, no scratches (case + protector since day one).\n\n📦 What's included:\n• Original box + unused cable\n• 2x cases + tempered glass applied\n• Receipt from Apple Store\n\n✨ Adult-owned, pet & smoke-free home. Can demo on pickup or video call. Pickup, meetup, or same-day shipping. Message me — I reply within an hour!",
    category: "Phones", brand: "Apple", condition: "Excellent",
    price: 42900, originalPrice: 79900, status: "active", qualityScore: 92,
    marketplaces: ["facebook", "ebay", "dubizzle"], keywords: ["unlocked", "battery health", "original box", "face id"],
    images: ["https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=800&q=80", "https://images.unsplash.com/photo-1591337676887-a217a6970a8a?w=800&q=80", "https://images.unsplash.com/photo-1510557880182-3d4d3cba35a5?w=800&q=80", "https://images.unsplash.com/photo-1580910051074-3eb694886505?w=800&q=80"],
    views: 1243, inquiries: 38,
  },
  {
    title: "MacBook Air M1 2020 8/256 — Battery 91%, Space Gray",
    description: "✅ FOR SALE: MacBook Air M1 (2020)\n\nCondition: Like New — 142 battery cycles, health 91%. No dents, keyboard perfect, screen flawless. Fresh macOS install.\n\n📦 Included: original 30W charger + cable, sleeve, box.\n\nIdeal for students/devs — silent, 15h battery. Can demo benchmarks on call. Price firm but open to quick-pickup offers!",
    category: "Laptops & Computers", brand: "Apple", condition: "Like New",
    price: 64900, originalPrice: 99900, status: "active", qualityScore: 88,
    marketplaces: ["ebay", "facebook", "noon"], keywords: ["m1", "ssd", "charger included", "no dead pixels"],
    images: ["https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=800&q=80", "https://images.unsplash.com/photo-1611186871348-b1ce696e52c9?w=800&q=80", "https://images.unsplash.com/photo-1541807084-5c52b6b3adef?w=800&q=80"],
    views: 986, inquiries: 24,
  },
  {
    title: "Sony WH-1000XM4 Noise Cancelling — Like New, Low Hours",
    description: "Sony's flagship ANC headphones. Used on 3 flights only — adult owned, pads perfect, 30h battery. Original case, cables, airplane adapter. Multipoint + LDAC. Retails $349 — grab for half. Pickup or shipped same day!",
    category: "Audio", brand: "Sony", condition: "Like New",
    price: 17900, originalPrice: 34900, status: "active", qualityScore: 84,
    marketplaces: ["facebook", "amazon", "depop"], keywords: ["noise cancelling", "bluetooth", "original case"],
    images: ["https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&q=80", "https://images.unsplash.com/photo-1583394838336-acd977736f90?w=800&q=80", "https://images.unsplash.com/photo-1546435770-a3e426bf472b?w=800&q=80", "https://images.unsplash.com/photo-1484704849700-f032a568e944?w=800&q=80"],
    views: 743, inquiries: 19,
  },
  {
    title: "Trek Hybrid Bike Medium — New Tires, Fully Tuned",
    description: "Trek FX hybrid, size M (fits 5'6–5'11). Full tune-up this month: new Kenda tires, new brake pads, gears indexed. Shimano 21-speed. Includes lock + LED lights + bottle holder. Garage kept, zero rust. Test ride welcome!",
    category: "Bikes & Scooters", brand: "Trek", condition: "Good",
    price: 28900, originalPrice: 59900, status: "active", qualityScore: 76,
    marketplaces: ["facebook", "craigslist", "opensooq"], keywords: ["tuned", "new tires", "shimano", "lock included"],
    images: ["https://images.unsplash.com/photo-1485965120184-e220f721d03e?w=800&q=80", "https://images.unsplash.com/photo-1507035895480-2b3156c31fc8?w=800&q=80"],
    views: 512, inquiries: 15,
  },
  {
    title: "Modern 3-Seater Fabric Sofa — Pet-Free, No Stains",
    description: "Stylish 3-seater, solid hardwood frame, washable charcoal covers. From pet & smoke-free home. Super comfy, no sagging. Selling due to move — must go this week! Can help disassemble. Ground-floor pickup, van can park at door.",
    category: "Home & Furniture", brand: "IKEA", condition: "Good",
    price: 24900, originalPrice: 69900, status: "active", qualityScore: 68,
    marketplaces: ["facebook", "dubizzle", "opensooq"], keywords: ["solid wood", "pet-free", "no stains"],
    images: ["https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=800&q=80", "https://images.unsplash.com/photo-1493663284031-b7e3aefcae0e?w=800&q=80", "https://images.unsplash.com/photo-1540574163026-643ea20ade25?w=800&q=80"],
    views: 431, inquiries: 11,
  },
  {
    title: "Sony A6400 Mirrorless + 16-50mm — Shutter 8K Only",
    description: "Sony A6400 body + 16-50mm OSS kit lens. Shutter count only ~8,200. Sensor professionally cleaned. Includes 2 batteries, charger, 64GB SD, strap, bag. Perfect for YouTube (flip screen + 4K). Sample shots available on request!",
    category: "Cameras", brand: "Sony", condition: "Excellent",
    price: 59900, originalPrice: 99800, status: "draft", qualityScore: 81,
    marketplaces: ["ebay"], keywords: ["shutter count", "sensor clean", "kit lens"],
    images: ["https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=800&q=80", "https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=800&q=80"],
    views: 0, inquiries: 0,
  },
  {
    title: "PlayStation 5 Disc Edition + 2 Controllers — Mint",
    description: "PS5 disc edition 825GB, adult-owned, dust-free. 2x DualSense (white + black), charging dock, 3 games (FC 25, Spider-Man 2, Elden Ring). All cables + stand. SOLD pending pickup — backup offers welcome!",
    category: "Gaming", brand: "Sony", condition: "Like New",
    price: 39900, originalPrice: 49900, status: "sold", qualityScore: 90,
    marketplaces: ["facebook", "ebay"], keywords: ["disc edition", "2 controllers", "dust free"],
    images: ["https://images.unsplash.com/photo-1606813907291-d86efa9b94db?w=800&q=80", "https://images.unsplash.com/photo-1622297845775-5ff17720125d?w=800&q=80", "https://images.unsplash.com/photo-1607853202273-797f1c22a38e?w=800&q=80"],
    views: 2104, inquiries: 67,
  },
  {
    title: "Dyson V11 Cordless Vacuum — New Filter, All Attachments",
    description: "Dyson V11 Absolute. New washable filter, all 6 heads incl. torque-drive + soft roller. 60-min eco runtime. Wall mount + charger. Fully descaled bins. Selling because we got a robot vac. Demo available!",
    category: "Appliances", brand: "Dyson", condition: "Good",
    price: 22900, originalPrice: 59900, status: "active", qualityScore: 74,
    marketplaces: ["facebook", "noon", "amazon"], keywords: ["cordless", "attachments", "filter"],
    images: ["https://images.unsplash.com/photo-1558317374-067fb5f30001?w=800&q=80"],
    views: 298, inquiries: 8,
  },
];

export async function ensureSeeded() {
  const existing = await db.select().from(users).where(eq(users.email, DEMO_EMAIL)).limit(1);
  let userId: string;
  if (existing[0]) {
    userId = existing[0].id;
    const count = await db.select({ id: listings.id }).from(listings).where(eq(listings.userId, userId));
    if (count.length >= 5) return { userId, seeded: false };
  } else {
    const hash = await hashPassword(DEMO_PASSWORD);
    const inserted = await db.insert(users).values({
      name: "Demo Seller",
      email: DEMO_EMAIL,
      passwordHash: hash,
      shopName: "Demo's Thrift Corner",
      avatarColor: "emerald",
    }).returning({ id: users.id });
    userId = inserted[0].id;
  }

  // wipe existing demo listings to keep seed fresh if re-run with few listings
  const prev = await db.select({ id: listings.id }).from(listings).where(eq(listings.userId, userId));
  for (const p of prev) {
    await db.delete(listingImages).where(eq(listingImages.listingId, p.id));
    await db.delete(listings).where(eq(listings.id, p.id));
  }
  await db.delete(negotiations).where(eq(negotiations.userId, userId));

  const listingIds: string[] = [];
  for (const s of SEED_LISTINGS) {
    const spread = Math.round(s.price * 0.12);
    const [row] = await db.insert(listings).values({
      userId,
      title: s.title,
      description: s.description,
      category: s.category,
      brand: s.brand,
      condition: s.condition,
      price: s.price,
      originalPrice: s.originalPrice,
      estimatedLow: s.price - spread,
      estimatedHigh: s.price + spread,
      suggestedPrice: s.price,
      status: s.status,
      qualityScore: s.qualityScore,
      marketplaceTargets: s.marketplaces,
      seoKeywords: s.keywords,
      views: s.views,
      inquiries: s.inquiries,
      aiAnalysis: { seeded: true, tags: s.keywords },
    }).returning({ id: listings.id });
    listingIds.push(row.id);
    for (let i = 0; i < s.images.length; i++) {
      await db.insert(listingImages).values({
        listingId: row.id,
        url: s.images[i],
        isPrimary: i === 0,
        sortOrder: i,
        aiTags: s.keywords.slice(0, 3),
      });
    }
  }

  const seedNegos = [
    { listingIdx: 0, buyerName: "Sara M.", buyerMessage: "Hi! Is the iPhone still available? Would you take $380?", offerPrice: 38000, askingPrice: 42900, status: "new", tone: "friendly" },
    { listingIdx: 1, buyerName: "Omar K.", buyerMessage: "Can you do $550 if I pick up today with cash?", offerPrice: 55000, askingPrice: 64900, status: "new", tone: "firm" },
    { listingIdx: 3, buyerName: "Lina", buyerMessage: "What's your last price for the bike? I can come this evening.", offerPrice: null as number | null, askingPrice: 28900, status: "new", tone: "friendly" },
    { listingIdx: 6, buyerName: "Yousef", buyerMessage: "I'll give you $200 cash right now for the PS5", offerPrice: 20000, askingPrice: 39900, status: "countered", tone: "firm" },
    { listingIdx: 4, buyerName: "Nour H.", buyerMessage: "Is the sofa from a pet-free home? Any stains? Can you deliver?", offerPrice: null as number | null, askingPrice: 24900, status: "accepted", tone: "professional" },
  ];
  for (const n of seedNegos) {
    await db.insert(negotiations).values({
      userId,
      listingId: listingIds[n.listingIdx],
      listingTitle: SEED_LISTINGS[n.listingIdx].title,
      buyerName: n.buyerName,
      buyerMessage: n.buyerMessage,
      offerPrice: n.offerPrice,
      askingPrice: n.askingPrice,
      status: n.status,
      tone: n.tone,
      suggestedReply: "",
    });
  }

  return { userId, seeded: true };
}
