CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), name text NOT NULL, email text NOT NULL UNIQUE,
  password_hash text NOT NULL, shop_name text, avatar_color text NOT NULL DEFAULT 'emerald', plan text NOT NULL DEFAULT 'free', subscription_status text NOT NULL DEFAULT 'inactive', lemon_subscription_id text, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS ai_usage (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE, month text NOT NULL, count integer NOT NULL DEFAULT 0, created_at timestamptz NOT NULL DEFAULT now());
CREATE UNIQUE INDEX IF NOT EXISTS ai_usage_user_month_idx ON ai_usage(user_id, month);
CREATE TABLE IF NOT EXISTS listings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title text NOT NULL, description text NOT NULL DEFAULT '', category text NOT NULL DEFAULT 'Other', brand text NOT NULL DEFAULT '',
  condition text NOT NULL DEFAULT 'Good', price integer NOT NULL DEFAULT 0, original_price integer, estimated_low integer, estimated_high integer,
  suggested_price integer, status text NOT NULL DEFAULT 'draft', quality_score integer NOT NULL DEFAULT 0,
  marketplace_targets jsonb NOT NULL DEFAULT '[]', ai_analysis jsonb DEFAULT '{}', seo_keywords jsonb NOT NULL DEFAULT '[]',
  views integer NOT NULL DEFAULT 0, inquiries integer NOT NULL DEFAULT 0, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS listing_images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), listing_id uuid NOT NULL REFERENCES listings(id) ON DELETE CASCADE,
  url text NOT NULL, is_primary boolean NOT NULL DEFAULT false, sort_order integer NOT NULL DEFAULT 0, ai_tags jsonb NOT NULL DEFAULT '[]', created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS negotiations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  listing_id uuid REFERENCES listings(id) ON DELETE SET NULL, listing_title text NOT NULL DEFAULT '', buyer_name text NOT NULL,
  buyer_message text NOT NULL, offer_price integer, asking_price integer NOT NULL DEFAULT 0, status text NOT NULL DEFAULT 'new',
  suggested_reply text NOT NULL DEFAULT '', tone text NOT NULL DEFAULT 'friendly', created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS listings_user_updated_idx ON listings(user_id, updated_at DESC);
CREATE INDEX IF NOT EXISTS listing_images_listing_idx ON listing_images(listing_id, sort_order);
CREATE INDEX IF NOT EXISTS negotiations_user_created_idx ON negotiations(user_id, created_at DESC);

