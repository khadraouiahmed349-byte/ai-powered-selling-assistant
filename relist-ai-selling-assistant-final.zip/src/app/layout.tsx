import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "ReList AI — Used Product Selling Assistant",
  description:
    "AI photo analysis, automatic product identification, AI-generated listing titles and descriptions, price estimation, marketplace optimization, negotiation assistant & more for second-hand sellers.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-slate-50 text-slate-900 antialiased min-h-screen">
        {children}
      </body>
    </html>
  );
}
