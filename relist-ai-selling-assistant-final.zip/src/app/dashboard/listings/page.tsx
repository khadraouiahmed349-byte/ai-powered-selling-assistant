"use client";
import { useEffect, useMemo, useState, Suspense } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { PlusCircle, Search, PackageSearch, SlidersHorizontal } from "lucide-react";
import { SectionTitle, EmptyState, ListingGridSkeleton, Toast } from "@/components/ui";
import ListingCard, { type CardListing } from "@/components/ListingCard";
import { cn } from "@/lib/utils";

type FullListing = CardListing & { description: string; brand: string };

const TABS = [
  { id: "all", label: "All" },
  { id: "active", label: "Active" },
  { id: "draft", label: "Drafts" },
  { id: "sold", label: "Sold" },
  { id: "archived", label: "Archived" },
];

function ListingsInner() {
  const searchParams = useSearchParams();
  const [listings, setListings] = useState<FullListing[]>([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState(searchParams.get("status") || "all");
  const [q, setQ] = useState("");
  const [sort, setSort] = useState("newest");
  const [toast, setToast] = useState<string | null>(null);

  const showToast = (m: string) => { setToast(m); setTimeout(() => setToast(null), 2200); };

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch("/api/listings");
        const data = await res.json();
        setListings(data.listings ?? []);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const counts = useMemo(() => {
    const c: Record<string, number> = { all: listings.length };
    for (const t of TABS.slice(1)) c[t.id] = listings.filter((l) => l.status === t.id).length;
    return c;
  }, [listings]);

  const filtered = useMemo(() => {
    let rows = [...listings];
    if (tab !== "all") rows = rows.filter((l) => l.status === tab);
    if (q.trim()) {
      const needle = q.toLowerCase();
      rows = rows.filter((l) => `${l.title} ${l.description} ${l.category} ${l.brand}`.toLowerCase().includes(needle));
    }
    if (sort === "price-high") rows.sort((a, b) => b.price - a.price);
    else if (sort === "price-low") rows.sort((a, b) => a.price - b.price);
    else if (sort === "score") rows.sort((a, b) => b.qualityScore - a.qualityScore);
    else if (sort === "views") rows.sort((a, b) => b.views - a.views);
    else rows.sort((a, b) => +new Date(b.updatedAt) - +new Date(a.updatedAt));
    return rows;
  }, [listings, tab, q, sort]);

  // optimistic delete
  const handleDelete = async (id: string) => {
    if (!confirm("Delete this listing? This cannot be undone.")) return;
    const prev = listings;
    setListings((ls) => ls.filter((l) => l.id !== id));
    try {
      const res = await fetch(`/api/listings/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error();
      showToast("Listing deleted");
    } catch {
      setListings(prev);
      showToast("Delete failed — restored");
    }
  };

  return (
    <div className="space-y-5 animate-fadeUp">
      <SectionTitle
        eyebrow="Inventory"
        title="My Listings"
        desc={`${listings.length} listings · full CRUD with instant updates`}
        action={
          <Link href="/dashboard/new" className="inline-flex items-center gap-2 rounded-2xl bg-emerald-600 px-5 py-2.5 text-sm font-bold text-white shadow-lg shadow-emerald-600/25 transition hover:bg-emerald-700 active:scale-95">
            <PlusCircle size={17} /> New listing
          </Link>
        }
      />

      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search size={17} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            value={q} onChange={(e) => setQ(e.target.value)}
            placeholder="Search titles, brands, categories…"
            className="w-full rounded-xl border border-slate-200 bg-white py-3 pl-10 pr-4 text-sm outline-none placeholder:text-slate-400 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100"
          />
        </div>
        <div className="flex items-center gap-2">
          <SlidersHorizontal size={16} className="text-slate-400" />
          <select value={sort} onChange={(e) => setSort(e.target.value)}
            className="rounded-xl border border-slate-200 bg-white px-3.5 py-3 text-sm font-semibold outline-none focus:border-emerald-500">
            <option value="newest">Newest first</option>
            <option value="score">Highest score</option>
            <option value="views">Most views</option>
            <option value="price-high">Price: high → low</option>
            <option value="price-low">Price: low → high</option>
          </select>
        </div>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-1">
        {TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={cn(
              "flex shrink-0 items-center gap-2 rounded-full px-4 py-2 text-sm font-bold transition",
              tab === t.id ? "bg-slate-900 text-white shadow-md" : "bg-white text-slate-600 ring-1 ring-slate-200 hover:bg-slate-50"
            )}
          >
            {t.label}
            <span className={cn("rounded-full px-1.5 py-0.5 text-[11px]", tab === t.id ? "bg-white/20" : "bg-slate-100")}>
              {counts[t.id] ?? 0}
            </span>
          </button>
        ))}
      </div>

      {loading ? (
        <ListingGridSkeleton count={6} />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={<PackageSearch size={26} />}
          title={q ? `No results for "${q}"` : tab === "all" ? "No listings yet" : `No ${tab} listings`}
          desc={q ? "Try a different keyword or clear the search." : "Create your first AI-assisted listing from your product details and photos."}
          action={
            <Link href="/dashboard/new" className="inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-5 py-2.5 text-sm font-bold text-white hover:bg-emerald-700">
              <PlusCircle size={16} /> Create listing
            </Link>
          }
        />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {filtered.map((l) => <ListingCard key={l.id} listing={l} onDelete={handleDelete} />)}
        </div>
      )}
      <Toast message={toast} />
    </div>
  );
}

export default function ListingsPage() {
  return (
    <Suspense fallback={<ListingGridSkeleton count={6} />}>
      <ListingsInner />
    </Suspense>
  );
}
