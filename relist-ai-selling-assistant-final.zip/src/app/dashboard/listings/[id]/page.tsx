"use client";
import { use, useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  ArrowLeft, Sparkles, Loader2, Trash2, Check, X, Eye, MessageCircle,
  Rocket, Tag, PenLine, Save,
} from "lucide-react";
import { Card, SectionTitle, Skeleton, ScoreRing, Toast } from "@/components/ui";
import PhotoUploader from "@/components/PhotoUploader";
import CopyButton from "@/components/CopyButton";
import { CATEGORIES, CONDITIONS, MARKETPLACES, STATUS_META, formatMoney, cn, scoreColor } from "@/lib/utils";

type Img = { url: string };
type Listing = {
  id: string; title: string; description: string; category: string; brand: string;
  condition: string; price: number; originalPrice: number | null;
  estimatedLow: number | null; estimatedHigh: number | null; suggestedPrice: number | null;
  status: string; qualityScore: number; marketplaceTargets: string[];
  seoKeywords: string[]; views: number; inquiries: number; images: Img[];
};

async function ai(action: string, payload: Record<string, unknown>) {
  const res = await fetch("/api/ai", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action, ...payload }) });
  return res.json();
}

export default function ListingDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const router = useRouter();
  const [listing, setListing] = useState<Listing | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [genTitles, setGenTitles] = useState<string[]>([]);
  const [estimate, setEstimate] = useState<{ low: number; high: number; suggested: number; sellFast: number; reasoning: string[] } | null>(null);
  const [scoreDetail, setScoreDetail] = useState<{ score: number; checks: Array<{ label: string; passed: boolean; fix: string }> } | null>(null);
  const [optMarket, setOptMarket] = useState("facebook");
  const [optResult, setOptResult] = useState<{ title: string; checklist: Array<{ task: string; done: boolean; why: string }>; proTip: string } | null>(null);
  const [form, setForm] = useState({ title: "", description: "", category: "Other", brand: "", condition: "Good", priceDollars: "", originalDollars: "", status: "draft", marketplaces: [] as string[] });
  const [images, setImages] = useState<string[]>([]);

  const showToast = (m: string) => { setToast(m); setTimeout(() => setToast(null), 2200); };

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch(`/api/listings/${id}`);
        const data = await res.json();
        if (!res.ok) { router.push("/dashboard/listings"); return; }
        const l: Listing = data.listing;
        setListing(l);
        setForm({
          title: l.title, description: l.description, category: l.category, brand: l.brand,
          condition: l.condition, priceDollars: l.price ? String(l.price / 100) : "",
          originalDollars: l.originalPrice ? String(l.originalPrice / 100) : "",
          status: l.status, marketplaces: l.marketplaceTargets ?? [],
        });
        setImages(l.images.map((i) => i.url));
      } finally {
        setLoading(false);
      }
    })();
  }, [id, router]);

  const save = async (overrides?: Partial<typeof form>) => {
    const f = { ...form, ...overrides };
    setSaving(true);
    try {
      const res = await fetch(`/api/listings/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: f.title, description: f.description, category: f.category, brand: f.brand,
          condition: f.condition, price: Math.round(parseFloat(f.priceDollars || "0") * 100),
          originalPrice: f.originalDollars ? Math.round(parseFloat(f.originalDollars) * 100) : null,
          status: f.status, marketplaceTargets: f.marketplaces, images,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setListing(data.listing);
      setForm({ ...f, status: data.listing.status });
      showToast("Saved ✓ Quality score updated");
    } catch {
      showToast("Save failed");
    } finally {
      setSaving(false);
    }
  };

  const doDelete = async () => {
    if (!confirm("Delete this listing permanently?")) return;
    await fetch(`/api/listings/${id}`, { method: "DELETE" });
    router.push("/dashboard/listings");
  };

  const runGenerate = async () => {
    setBusy("generate");
    try {
      const { result } = await ai("generate", { productHint: form.brand ? `${form.brand} ${form.category}` : form.title || form.category, category: form.category, condition: form.condition, brand: form.brand });
      if (result) {
        setGenTitles(result.titles);
        setForm((f) => ({ ...f, description: result.description }));
        showToast("AI description generated — review & save");
      }
    } finally { setBusy(null); }
  };

  const runEstimate = async () => {
    setBusy("estimate");
    try {
      const { result } = await ai("estimate", {
        category: form.category, condition: form.condition,
        originalPriceCents: form.originalDollars ? Math.round(parseFloat(form.originalDollars) * 100) : null,
        hint: form.title,
      });
      if (result) setEstimate(result);
    } finally { setBusy(null); }
  };

  const runScore = async () => {
    setBusy("score");
    try {
      const { result } = await ai("score", {
        title: form.title, description: form.description,
        priceCents: Math.round(parseFloat(form.priceDollars || "0") * 100),
        imageCount: images.length, category: form.category, brand: form.brand, condition: form.condition,
      });
      if (result) setScoreDetail(result);
    } finally { setBusy(null); }
  };

  const runOptimize = async (mkt: string) => {
    setOptMarket(mkt);
    setBusy("optimize");
    try {
      const { result } = await ai("optimize", {
        marketplace: mkt, title: form.title, description: form.description,
        priceCents: Math.round(parseFloat(form.priceDollars || "0") * 100), imageCount: images.length,
      });
      if (result) setOptResult(result);
    } finally { setBusy(null); }
  };

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-10 w-64" />
        <div className="grid gap-4 lg:grid-cols-3">
          <Skeleton className="h-[420px]" />
          <Skeleton className="h-[420px] lg:col-span-2" />
        </div>
      </div>
    );
  }
  if (!listing) return null;
  const st = STATUS_META[listing.status] ?? STATUS_META.draft;
  const sc = scoreColor(listing.qualityScore);
  const fullListingText = `${form.title}\n${formatMoney(Math.round(parseFloat(form.priceDollars || "0") * 100))} · ${form.condition} · ${form.category}\n\n${form.description}`;

  return (
    <div className="space-y-5 animate-fadeUp">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <Link href="/dashboard/listings" className="inline-flex items-center gap-1.5 text-sm font-bold text-slate-600 hover:text-slate-900">
          <ArrowLeft size={16} /> Back to listings
        </Link>
        <div className="flex flex-wrap items-center gap-2">
          <span className={cn("inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-bold ring-1", st.classes)}>
            <span className={cn("h-1.5 w-1.5 rounded-full", st.dot)} />{st.label}
          </span>
          <span className="flex items-center gap-3 text-xs text-slate-500">
            <span className="flex items-center gap-1"><Eye size={14} /> {listing.views}</span>
            <span className="flex items-center gap-1"><MessageCircle size={14} /> {listing.inquiries}</span>
          </span>
        </div>
      </div>

      <SectionTitle
        title="Edit listing"
        desc="Update details, run AI tools, then save. Score refreshes on every save."
        action={
          <div className="flex gap-2">
            <button onClick={doDelete} className="inline-flex items-center gap-1.5 rounded-xl bg-rose-50 px-4 py-2.5 text-sm font-bold text-rose-600 ring-1 ring-rose-200 hover:bg-rose-100">
              <Trash2 size={15} /> Delete
            </button>
            <button onClick={() => save()} disabled={saving} className="inline-flex items-center gap-1.5 rounded-xl bg-emerald-600 px-5 py-2.5 text-sm font-bold text-white shadow-lg shadow-emerald-600/25 hover:bg-emerald-700 disabled:opacity-60">
              {saving ? <Loader2 size={15} className="animate-spin" /> : <Save size={15} />} Save changes
            </button>
          </div>
        }
      />

      <div className="grid gap-4 lg:grid-cols-3">
        {/* LEFT: photos + status */}
        <div className="space-y-4">
          <Card className="p-5">
            <h3 className="text-sm font-bold">Photos ({images.length})</h3>
            <div className="mt-3"><PhotoUploader images={images} onChange={setImages} /></div>
          </Card>
          <Card className="p-5">
            <h3 className="text-sm font-bold">Status & marketplaces</h3>
            <div className="mt-3 grid grid-cols-2 gap-2">
              {["draft", "active", "sold", "archived"].map((s) => (
                <button key={s} onClick={() => { setForm({ ...form, status: s }); save({ status: s }); }}
                  className={cn("rounded-xl px-3 py-2 text-xs font-bold capitalize ring-1 transition",
                    form.status === s ? "bg-slate-900 text-white ring-slate-900" : "bg-white text-slate-600 ring-slate-200 hover:bg-slate-50")}>
                  {s}
                </button>
              ))}
            </div>
            <p className="mt-4 text-xs font-bold text-slate-500">TARGET MARKETPLACES</p>
            <div className="mt-2 flex flex-wrap gap-1.5">
              {MARKETPLACES.map((m) => {
                const on = form.marketplaces.includes(m.id);
                return (
                  <button key={m.id} onClick={() => setForm({ ...form, marketplaces: on ? form.marketplaces.filter((x) => x !== m.id) : [...form.marketplaces, m.id] })}
                    className={cn("rounded-full px-3 py-1.5 text-xs font-bold ring-1 transition", on ? "bg-emerald-600 text-white ring-emerald-600" : "bg-white text-slate-600 ring-slate-200 hover:ring-slate-300")}>
                    {m.name}
                  </button>
                );
              })}
            </div>
            <div className="mt-4 rounded-xl bg-slate-50 p-3">
              <div className="flex items-center gap-3">
                <ScoreRing score={listing.qualityScore} />
                <div>
                  <p className="text-sm font-bold">Quality score</p>
                  <p className={cn("text-xs font-bold", sc.text)}>{sc.label}</p>
                </div>
                <button onClick={runScore} disabled={busy === "score"} className="ml-auto rounded-lg bg-white px-3 py-2 text-xs font-bold ring-1 ring-slate-200 hover:bg-slate-50">
                  {busy === "score" ? <Loader2 size={14} className="animate-spin" /> : "Re-check"}
                </button>
              </div>
              {scoreDetail && (
                <ul className="mt-3 space-y-1.5">
                  {scoreDetail.checks.map((c, i) => (
                    <li key={i} className="flex items-start gap-2 text-xs">
                      {c.passed ? <Check size={14} className="mt-0.5 shrink-0 text-emerald-600" strokeWidth={3} /> : <X size={14} className="mt-0.5 shrink-0 text-rose-500" strokeWidth={3} />}
                      <span className={c.passed ? "text-slate-600" : "font-semibold text-slate-800"}>{c.passed ? c.label : c.fix}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </Card>
        </div>

        {/* RIGHT: form + AI */}
        <div className="space-y-4 lg:col-span-2">
          <Card className="p-5">
            <div className="flex items-center justify-between">
              <h3 className="flex items-center gap-1.5 text-sm font-bold"><PenLine size={15} className="text-emerald-600" /> Title & description</h3>
              <button onClick={runGenerate} disabled={busy === "generate"} className="inline-flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 px-3.5 py-2 text-xs font-bold text-white hover:opacity-95 disabled:opacity-60">
                {busy === "generate" ? <Loader2 size={14} className="animate-spin" /> : <Sparkles size={14} />} AI rewrite
              </button>
            </div>
            {genTitles.length > 0 && (
              <div className="mt-3 space-y-1.5 rounded-xl bg-emerald-50/60 p-3 ring-1 ring-emerald-100">
                <p className="text-[11px] font-bold uppercase tracking-wider text-emerald-700">AI title options — click to use</p>
                {genTitles.map((t, i) => (
                  <button key={i} onClick={() => setForm({ ...form, title: t })}
                    className="block w-full rounded-lg bg-white px-3 py-2 text-left text-[13px] font-semibold text-slate-800 ring-1 ring-emerald-100 transition hover:ring-emerald-400">
                    {t}
                  </button>
                ))}
              </div>
            )}
            <label className="mt-3 block text-xs font-bold text-slate-700">Title <span className="font-medium text-slate-400">({form.title.length}/80)</span></label>
            <input value={form.title} maxLength={120} onChange={(e) => setForm({ ...form, title: e.target.value })}
              className="mt-1.5 w-full rounded-xl border border-slate-200 px-4 py-3 text-sm font-semibold outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100" />
            <label className="mt-3 block text-xs font-bold text-slate-700">Description <span className="font-medium text-slate-400">({form.description.length} chars)</span></label>
            <textarea value={form.description} rows={10} onChange={(e) => setForm({ ...form, description: e.target.value })}
              className="mt-1.5 w-full rounded-xl border border-slate-200 px-4 py-3 text-sm leading-relaxed outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100" />
            <div className="mt-3 flex flex-wrap gap-2">
              <CopyButton text={form.title} label="Copy title" small />
              <CopyButton text={form.description} label="Copy description" small />
              <CopyButton text={fullListingText} label="Copy full listing" small />
            </div>
          </Card>

          <div className="grid gap-4 sm:grid-cols-2">
            <Card className="p-5">
              <h3 className="text-sm font-bold">Details & pricing</h3>
              <div className="mt-3 grid grid-cols-2 gap-2.5">
                <div>
                  <label className="text-xs font-bold text-slate-500">Category</label>
                  <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm outline-none focus:border-emerald-500">
                    {CATEGORIES.map((c) => <option key={c}>{c}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-500">Condition</label>
                  <select value={form.condition} onChange={(e) => setForm({ ...form, condition: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm outline-none focus:border-emerald-500">
                    {CONDITIONS.map((c) => <option key={c}>{c}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-500">Brand</label>
                  <input value={form.brand} onChange={(e) => setForm({ ...form, brand: e.target.value })} placeholder="Apple, IKEA…"
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm outline-none focus:border-emerald-500" />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-500">Your price ($)</label>
                  <input type="number" min="0" step="0.01" value={form.priceDollars} onChange={(e) => setForm({ ...form, priceDollars: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm font-bold outline-none focus:border-emerald-500" />
                </div>
              </div>
              <div className="mt-2.5">
                <label className="text-xs font-bold text-slate-500">Original retail ($, optional — improves estimate)</label>
                <input type="number" min="0" step="0.01" value={form.originalDollars} onChange={(e) => setForm({ ...form, originalDollars: e.target.value })}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm outline-none focus:border-emerald-500" />
              </div>
              <button onClick={runEstimate} disabled={busy === "estimate"}
                className="mt-3 inline-flex w-full items-center justify-center gap-1.5 rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-bold text-white hover:bg-slate-700 disabled:opacity-60">
                {busy === "estimate" ? <Loader2 size={15} className="animate-spin" /> : <Tag size={15} />} Estimate price
              </button>
              {estimate && (
                <div className="mt-3 rounded-xl bg-amber-50/70 p-3.5 ring-1 ring-amber-100">
                  <div className="grid grid-cols-3 gap-2 text-center">
                    <div><p className="text-[11px] font-bold text-slate-500">FAIR RANGE</p><p className="text-sm font-extrabold">{formatMoney(estimate.low)}–{formatMoney(estimate.high)}</p></div>
                    <div><p className="text-[11px] font-bold text-emerald-700">SUGGESTED</p><p className="text-sm font-extrabold text-emerald-700">{formatMoney(estimate.suggested)}</p></div>
                    <div><p className="text-[11px] font-bold text-slate-500">SELL FAST</p><p className="text-sm font-extrabold">{formatMoney(estimate.sellFast)}</p></div>
                  </div>
                  <button onClick={() => setForm({ ...form, priceDollars: String(estimate.suggested / 100) })}
                    className="mt-2.5 w-full rounded-lg bg-emerald-600 py-2 text-xs font-bold text-white hover:bg-emerald-700">
                    Use suggested price {formatMoney(estimate.suggested)}
                  </button>
                  <ul className="mt-2 space-y-1">
                    {estimate.reasoning.map((r, i) => <li key={i} className="text-[11px] leading-relaxed text-slate-600">• {r}</li>)}
                  </ul>
                </div>
              )}
            </Card>

            <Card className="p-5">
              <h3 className="flex items-center gap-1.5 text-sm font-bold"><Rocket size={15} className="text-rose-500" /> Marketplace optimizer</h3>
              <div className="mt-2.5 flex flex-wrap gap-1.5">
                {MARKETPLACES.slice(0, 8).map((m) => (
                  <button key={m.id} onClick={() => runOptimize(m.id)}
                    className={cn("rounded-full px-3 py-1.5 text-xs font-bold ring-1 transition", optMarket === m.id ? "bg-slate-900 text-white ring-slate-900" : "bg-white text-slate-600 ring-slate-200 hover:bg-slate-50")}>
                    {m.name}
                  </button>
                ))}
              </div>
              <div className="mt-3 min-h-[180px] rounded-xl bg-slate-50 p-3.5">
                {busy === "optimize" ? (
                  <p className="flex items-center gap-2 text-sm text-slate-500"><Loader2 size={16} className="animate-spin" /> Analyzing for {MARKETPLACES.find((m) => m.id === optMarket)?.name}…</p>
                ) : optResult ? (
                  <div>
                    <p className="text-xs font-bold">{optResult.title}</p>
                    <ul className="mt-2 space-y-1.5">
                      {optResult.checklist.map((c, i) => (
                        <li key={i} className="flex items-start gap-2 text-xs">
                          {c.done ? <Check size={14} className="mt-0.5 shrink-0 text-emerald-600" strokeWidth={3} /> : <span className="mt-1 h-2 w-2 shrink-0 rounded-full bg-amber-500" />}
                          <span><span className="font-semibold text-slate-800">{c.task}</span> <span className="text-slate-500">— {c.why}</span></span>
                        </li>
                      ))}
                    </ul>
                    <p className="mt-2.5 rounded-lg bg-white p-2.5 text-xs ring-1 ring-slate-200"><span className="font-bold">💡 Pro tip:</span> {optResult.proTip}</p>
                  </div>
                ) : (
                  <p className="text-xs leading-relaxed text-slate-500">Pick a marketplace to get a tailored optimization checklist for this listing.</p>
                )}
              </div>
            </Card>
          </div>
        </div>
      </div>
      <Toast message={toast} />
    </div>
  );
}
