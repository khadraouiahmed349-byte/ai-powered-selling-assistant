"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { Rocket, Loader2, Check, ArrowRight } from "lucide-react";
import { Card, SectionTitle, Skeleton } from "@/components/ui";
import CopyButton from "@/components/CopyButton";
import { MARKETPLACES, cn } from "@/lib/utils";

type Listing = {
  id: string; title: string; description: string; price: number;
  images: Array<{ url: string }>; qualityScore: number; category: string;
};

export default function OptimizerPage() {
  const [listings, setListings] = useState<Listing[]>([]);
  const [loading, setLoading] = useState(true);
  const [listingId, setListingId] = useState("");
  const [market, setMarket] = useState("ebay");
  const [result, setResult] = useState<{ title: string; checklist: Array<{ task: string; done: boolean; why: string }>; proTip: string } | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch("/api/listings");
        const data = await res.json();
        setListings(data.listings ?? []);
        if (data.listings?.length) setListingId(data.listings[0].id);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const selected = listings.find((l) => l.id === listingId);

  const run = async (mkt?: string, lid?: string) => {
    const l = listings.find((x) => x.id === (lid ?? listingId));
    if (!l) return;
    setBusy(true);
    setResult(null);
    try {
      const res = await fetch("/api/ai", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "optimize", marketplace: mkt ?? market,
          title: l.title, description: l.description, priceCents: l.price, imageCount: l.images.length,
        }),
      });
      const data = await res.json();
      setResult(data.result);
    } finally {
      setBusy(false);
    }
  };

  const doneCount = result?.checklist.filter((c) => c.done).length ?? 0;

  return (
    <div className="mx-auto max-w-4xl space-y-6 animate-fadeUp">
      <SectionTitle
        eyebrow="Sell everywhere"
        title="Marketplace Optimizer"
        desc="One listing, tuned for every platform's algorithm"
      />

      {loading ? (
        <div className="space-y-3"><Skeleton className="h-24" /><Skeleton className="h-64" /></div>
      ) : listings.length === 0 ? (
        <Card className="p-10 text-center">
          <Rocket size={28} className="mx-auto text-slate-300" />
          <p className="mt-2 font-bold">No listings to optimize</p>
          <p className="mt-1 text-sm text-slate-500">Create a listing first, then come back to tune it per marketplace.</p>
          <Link href="/dashboard/new" className="mt-4 inline-block rounded-xl bg-emerald-600 px-5 py-2.5 text-sm font-bold text-white">Create listing</Link>
        </Card>
      ) : (
        <>
          <Card className="p-5">
            <label className="text-xs font-bold text-slate-700">Choose a listing to optimize</label>
            <select value={listingId} onChange={(e) => { setListingId(e.target.value); setResult(null); }}
              className="mt-1.5 w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold outline-none focus:border-emerald-500">
              {listings.map((l) => <option key={l.id} value={l.id}>{l.title.slice(0, 70)} · score {l.qualityScore}</option>)}
            </select>
            {selected && (
              <div className="mt-3 flex gap-3 rounded-xl bg-slate-50 p-3">
                {selected.images[0] ? <img src={selected.images[0].url} alt="" className="h-16 w-16 rounded-lg object-cover" /> : <span className="grid h-16 w-16 place-items-center rounded-lg bg-slate-200 text-2xl">📦</span>}
                <div className="min-w-0">
                  <p className="line-clamp-2 text-sm font-bold">{selected.title}</p>
                  <Link href={`/dashboard/listings/${selected.id}`} className="mt-1 inline-flex items-center gap-1 text-xs font-bold text-emerald-700 hover:underline">
                    Edit listing <ArrowRight size={12} />
                  </Link>
                </div>
              </div>
            )}
          </Card>

          <div>
            <p className="text-xs font-bold uppercase tracking-wider text-slate-500">Pick a marketplace</p>
            <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-4">
              {MARKETPLACES.map((m) => (
                <button key={m.id} onClick={() => { setMarket(m.id); run(m.id); }}
                  className={cn("rounded-2xl border p-3.5 text-left transition",
                    market === m.id ? "border-slate-900 bg-slate-900 text-white shadow-lg" : "border-slate-200 bg-white hover:border-slate-300 hover:shadow")}>
                  <p className="text-sm font-bold">{m.name}</p>
                  <p className={cn("mt-0.5 text-[11px]", market === m.id ? "text-slate-300" : "text-slate-500")}>Fee: {m.fee}</p>
                  <p className={cn("mt-1 line-clamp-2 text-[11px] leading-snug", market === m.id ? "text-slate-300" : "text-slate-400")}>{m.tip}</p>
                </button>
              ))}
            </div>
          </div>

          <Card className="p-5 sm:p-6">
            {!result && !busy && (
              <div className="py-8 text-center">
                <span className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-rose-50 text-rose-500"><Rocket size={22} /></span>
                <p className="mt-3 font-bold">Ready to optimize for {MARKETPLACES.find((m) => m.id === market)?.name}</p>
                <button onClick={() => run()} className="mt-3 rounded-xl bg-slate-900 px-6 py-2.5 text-sm font-bold text-white hover:bg-slate-700">
                  Run optimization check
                </button>
              </div>
            )}
            {busy && (
              <p className="flex items-center justify-center gap-2 py-10 text-sm text-slate-500">
                <Loader2 size={17} className="animate-spin" /> Analyzing against {MARKETPLACES.find((m) => m.id === market)?.name} best practices…
              </p>
            )}
            {result && !busy && (
              <div className="animate-fadeUp">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <h3 className="font-bold">{result.title}</h3>
                  <span className="rounded-full bg-emerald-50 px-3 py-1 text-xs font-bold text-emerald-700 ring-1 ring-emerald-200">
                    {doneCount}/{result.checklist.length} checks passed
                  </span>
                </div>
                <div className="mt-2 h-2 overflow-hidden rounded-full bg-slate-100">
                  <div className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-teal-400 transition-all" style={{ width: `${(doneCount / result.checklist.length) * 100}%` }} />
                </div>
                <ul className="mt-4 space-y-2.5">
                  {result.checklist.map((c, i) => (
                    <li key={i} className={cn("flex items-start gap-3 rounded-xl p-3.5 ring-1", c.done ? "bg-emerald-50/50 ring-emerald-100" : "bg-amber-50/50 ring-amber-100")}>
                      {c.done
                        ? <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-emerald-500 text-white"><Check size={14} strokeWidth={3} /></span>
                        : <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-amber-500 text-xs font-bold text-white">!</span>}
                      <span>
                        <span className="block text-sm font-bold text-slate-800">{c.task}</span>
                        <span className="block text-xs text-slate-500">{c.why}</span>
                      </span>
                    </li>
                  ))}
                </ul>
                <div className="mt-4 rounded-xl bg-slate-900 p-4 text-white">
                  <p className="text-sm"><span className="font-bold text-emerald-300">💡 Pro tip: </span>{result.proTip}</p>
                </div>
                {selected && (
                  <div className="mt-3 flex flex-wrap gap-2">
                    <CopyButton small text={selected.title} label="Copy title" />
                    <CopyButton small text={selected.description} label="Copy description" />
                    <Link href={`/dashboard/listings/${selected.id}`} className="inline-flex items-center gap-1 rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-emerald-700">
                      Fix in editor <ArrowRight size={13} />
                    </Link>
                  </div>
                )}
              </div>
            )}
          </Card>
        </>
      )}
    </div>
  );
}
