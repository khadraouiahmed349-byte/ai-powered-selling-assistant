"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import {
  Package, Eye, MessageCircle, Banknote, PlusCircle, ArrowRight,
  Sparkles, TrendingUp, Calculator, MessagesSquare, Rocket, Loader2, Flame,
} from "lucide-react";
import { Card, SectionTitle, Skeleton, ScoreRing } from "@/components/ui";
import ListingCard, { type CardListing } from "@/components/ListingCard";
import { formatMoney } from "@/lib/utils";

type Stats = {
  total: number; active: number; draft: number; sold: number;
  totalViews: number; totalInquiries: number; revenue: number;
  inventoryValue: number; avgScore: number; openNegotiations: number;
};

export default function DashboardHome() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [recent, setRecent] = useState<CardListing[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const [s, l] = await Promise.all([
          fetch("/api/stats").then((r) => r.json()),
          fetch("/api/listings").then((r) => r.json()),
        ]);
        setStats(s.stats);
        setRecent((l.listings ?? []).slice(0, 3));
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const cards = stats ? [
    { icon: Package, label: "Active listings", value: String(stats.active), sub: `${stats.total} total · ${stats.draft} drafts`, tint: "bg-emerald-50 text-emerald-600" },
    { icon: Eye, label: "Total views", value: stats.totalViews.toLocaleString(), sub: `${stats.totalInquiries} inquiries`, tint: "bg-sky-50 text-sky-600" },
    { icon: Banknote, label: "Sold revenue", value: formatMoney(stats.revenue), sub: `${stats.sold} sold · ${formatMoney(stats.inventoryValue)} live value`, tint: "bg-amber-50 text-amber-600" },
    { icon: MessageCircle, label: "Open negotiations", value: String(stats.openNegotiations), sub: "AI replies ready", tint: "bg-violet-50 text-violet-600" },
  ] : [];

  return (
    <div className="space-y-6 animate-fadeUp">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-[0.14em] text-emerald-600">
            <Flame size={13} /> Seller command center
          </p>
          <h1 className="mt-1 text-2xl font-extrabold tracking-tight sm:text-3xl">Good to see you 👋</h1>
          <p className="mt-1 text-sm text-slate-500">Here&apos;s how your second-hand business is performing.</p>
        </div>
        <Link href="/dashboard/new" className="inline-flex items-center gap-2 rounded-2xl bg-emerald-600 px-5 py-3 text-sm font-bold text-white shadow-lg shadow-emerald-600/25 transition hover:bg-emerald-700 active:scale-95">
          <PlusCircle size={17} /> New AI listing
        </Link>
      </div>

      {loading ? (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-28" />)}
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {cards.map((c) => (
            <Card key={c.label} className="p-5">
              <div className="flex items-center justify-between">
                <span className={`grid h-10 w-10 place-items-center rounded-xl ${c.tint}`}><c.icon size={19} /></span>
              </div>
              <p className="mt-3 text-2xl font-extrabold tracking-tight">{c.value}</p>
              <p className="text-xs font-bold text-slate-500">{c.label}</p>
              <p className="mt-1 text-xs text-slate-400">{c.sub}</p>
            </Card>
          ))}
        </div>
      )}

      <div className="grid gap-4 lg:grid-cols-3">
        {/* AI quality */}
        <Card className="p-5 lg:col-span-1">
          <div className="flex items-center gap-1.5 text-sm font-bold"><Sparkles size={16} className="text-emerald-600" /> Avg. quality score</div>
          {loading ? <Skeleton className="mt-4 h-24" /> : (
            <div className="mt-4 flex items-center gap-4">
              <ScoreRing score={stats?.avgScore ?? 0} size={76} />
              <div>
                <p className="text-sm font-bold">Listings health</p>
                <p className="mt-1 text-xs leading-relaxed text-slate-500">
                  {(stats?.avgScore ?? 0) >= 80 ? "Excellent! Your listings are tuned to sell." : (stats?.avgScore ?? 0) >= 60 ? "Good — polish a few titles & photos to hit 80+." : "Room to grow — run the optimizer on each listing."}
                </p>
                <Link href="/dashboard/optimizer" className="mt-2 inline-flex items-center gap-1 text-xs font-bold text-emerald-700 hover:underline">
                  Open optimizer <ArrowRight size={13} />
                </Link>
              </div>
            </div>
          )}
          <div className="mt-4 space-y-2 border-t border-slate-100 pt-4">
            {[
              { icon: Calculator, label: "Estimate a price", href: "/dashboard/estimator" },
              { icon: MessagesSquare, label: "Answer a haggler", href: "/dashboard/negotiations" },
              { icon: Rocket, label: "Optimize for eBay / FB", href: "/dashboard/optimizer" },
            ].map((a) => (
              <Link key={a.label} href={a.href} className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold text-slate-700 transition hover:bg-slate-50">
                <span className="grid h-8 w-8 place-items-center rounded-lg bg-slate-100 text-slate-600"><a.icon size={15} /></span>
                {a.label}
                <ArrowRight size={14} className="ml-auto text-slate-300" />
              </Link>
            ))}
          </div>
        </Card>

        {/* recent listings */}
        <div className="lg:col-span-2">
          <SectionTitle
            title="Recent listings"
            desc="Your freshest inventory at a glance"
            action={<Link href="/dashboard/listings" className="inline-flex items-center gap-1 text-sm font-bold text-emerald-700 hover:underline">View all <ArrowRight size={15} /></Link>}
          />
          <div className="mt-4">
            {loading ? (
              <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
                {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-64" />)}
              </div>
            ) : recent.length === 0 ? (
              <Card className="flex flex-col items-center p-10 text-center">
                <span className="grid h-12 w-12 place-items-center rounded-2xl bg-emerald-50 text-emerald-600"><Package size={22} /></span>
                <p className="mt-3 font-bold">No listings yet</p>
                <p className="mt-1 text-sm text-slate-500">Create your first AI-powered listing in under a minute.</p>
                <Link href="/dashboard/new" className="mt-4 rounded-xl bg-slate-900 px-5 py-2.5 text-sm font-bold text-white">Create listing</Link>
              </Card>
            ) : (
              <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
                {recent.map((l) => <ListingCard key={l.id} listing={l} />)}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* AI tip banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-slate-900 via-slate-800 to-emerald-900 p-6 text-white sm:p-7">
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(30rem_12rem_at_80%_0%,rgba(52,211,153,0.25),transparent)]" />
        <div className="relative flex flex-wrap items-center gap-4">
          <span className="grid h-11 w-11 place-items-center rounded-2xl bg-emerald-500/20 text-emerald-300 ring-1 ring-emerald-400/30"><TrendingUp size={20} /></span>
          <div className="min-w-0 flex-1">
            <p className="font-bold">Pro tip: Clear photos and a strong quality score can make a listing easier to evaluate.</p>
            <p className="mt-0.5 text-sm text-slate-300">Run every draft through the AI optimizer before publishing — it takes 10 seconds.</p>
          </div>
          <Link href="/dashboard/listings?status=draft" className="rounded-xl bg-white px-5 py-2.5 text-sm font-bold text-slate-900 transition hover:bg-emerald-50">
            Polish drafts
          </Link>
        </div>
      </div>
    </div>
  );
}
