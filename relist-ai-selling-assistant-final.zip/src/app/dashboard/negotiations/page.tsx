"use client";
import { useEffect, useMemo, useState } from "react";
import { MessagesSquare, Loader2, Sparkles, Plus, Send, Trash2, MessageCircleOff } from "lucide-react";
import { Card, SectionTitle, EmptyState, Skeleton, Toast } from "@/components/ui";
import CopyButton from "@/components/CopyButton";
import { formatMoney, cn } from "@/lib/utils";

type Nego = {
  id: string; listingTitle: string; buyerName: string; buyerMessage: string;
  offerPrice: number | null; askingPrice: number; status: string;
  suggestedReply: string; tone: string; updatedAt: string;
};

const TONES = ["friendly", "firm", "professional", "playful"];
const STATUS_COLORS: Record<string, string> = {
  new: "bg-sky-50 text-sky-700 ring-sky-200",
  countered: "bg-amber-50 text-amber-700 ring-amber-200",
  accepted: "bg-emerald-50 text-emerald-700 ring-emerald-200",
  declined: "bg-slate-100 text-slate-500 ring-slate-200",
};

export default function NegotiationsPage() {
  const [negos, setNegos] = useState<Nego[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [generating, setGenerating] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [aiMeta, setAiMeta] = useState<{ verdict: string; counterCents: number; ratio: number; tips: string[] } | null>(null);
  const [form, setForm] = useState({ buyerName: "", buyerMessage: "", offerDollars: "", askingDollars: "", listingTitle: "", tone: "friendly" });

  const showToast = (m: string) => { setToast(m); setTimeout(() => setToast(null), 2200); };
  const selected = useMemo(() => negos.find((n) => n.id === selectedId) ?? null, [negos, selectedId]);

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch("/api/negotiations");
        const data = await res.json();
        setNegos(data.negotiations ?? []);
        if (data.negotiations?.length) setSelectedId(data.negotiations[0].id);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const generate = async (n: Nego, tone?: string) => {
    setGenerating(true);
    setAiMeta(null);
    try {
      const res = await fetch("/api/ai", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "negotiate",
          buyerMessage: n.buyerMessage,
          askingCents: n.askingPrice,
          offerCents: n.offerPrice,
          tone: tone ?? n.tone,
          listingTitle: n.listingTitle,
        }),
      });
      const data = await res.json();
      if (data.result) {
        setAiMeta({ verdict: data.result.verdict, counterCents: data.result.counterCents, ratio: data.result.ratio, tips: data.result.tips });
        // optimistic update + persist
        const reply = data.result.reply;
        setNegos((ns) => ns.map((x) => (x.id === n.id ? { ...x, suggestedReply: reply, tone: tone ?? x.tone } : x)));
        await fetch(`/api/negotiations/${n.id}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ suggestedReply: reply, tone: tone ?? n.tone }),
        });
        showToast("AI reply generated ✨");
      }
    } finally {
      setGenerating(false);
    }
  };

  const setStatus = async (n: Nego, status: string) => {
    const prev = negos;
    setNegos((ns) => ns.map((x) => (x.id === n.id ? { ...x, status } : x)));
    try {
      await fetch(`/api/negotiations/${n.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status }) });
      showToast(`Marked as ${status}`);
    } catch {
      setNegos(prev);
    }
  };

  const remove = async (id: string) => {
    const prev = negos;
    setNegos((ns) => ns.filter((x) => x.id !== id));
    if (selectedId === id) setSelectedId(null);
    try {
      await fetch(`/api/negotiations/${id}`, { method: "DELETE" });
      showToast("Conversation deleted");
    } catch {
      setNegos(prev);
    }
  };

  const create = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch("/api/negotiations", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        buyerName: form.buyerName, buyerMessage: form.buyerMessage,
        offerPrice: form.offerDollars ? Math.round(parseFloat(form.offerDollars) * 100) : null,
        askingPrice: Math.round(parseFloat(form.askingDollars || "0") * 100),
        listingTitle: form.listingTitle, tone: form.tone,
      }),
    });
    const data = await res.json();
    if (res.ok) {
      setNegos((ns) => [data.negotiation, ...ns]);
      setSelectedId(data.negotiation.id);
      setForm({ buyerName: "", buyerMessage: "", offerDollars: "", askingDollars: "", listingTitle: "", tone: "friendly" });
      setShowNew(false);
      showToast("Buyer added — generate a reply");
    }
  };

  const verdictLabel: Record<string, { t: string; c: string }> = {
    accept: { t: "✅ Good offer — accept it", c: "text-emerald-700" },
    "counter-small": { t: "🤝 Close — counter once", c: "text-sky-700" },
    "counter-firm": { t: "💪 Low — hold firm with a small move", c: "text-amber-700" },
    "decline-soft": { t: "🚫 Lowball — decline politely", c: "text-rose-600" },
    "no-offer": { t: "💬 Question — answer warmly + invite to view", c: "text-violet-700" },
  };

  return (
    <div className="space-y-5 animate-fadeUp">
      <SectionTitle
        eyebrow="Close more deals"
        title="Negotiation Assistant"
        desc="Paste buyer messages, get perfect replies with counter-offer math"
        action={
          <button onClick={() => setShowNew(!showNew)} className="inline-flex items-center gap-2 rounded-2xl bg-emerald-600 px-5 py-2.5 text-sm font-bold text-white shadow-lg shadow-emerald-600/25 hover:bg-emerald-700">
            <Plus size={16} /> Add buyer message
          </button>
        }
      />

      {showNew && (
        <Card className="p-5 animate-fadeUp">
          <h3 className="text-sm font-bold">New buyer inquiry</h3>
          <form onSubmit={create} className="mt-3 grid gap-2.5 sm:grid-cols-2">
            <input required value={form.buyerName} onChange={(e) => setForm({ ...form, buyerName: e.target.value })} placeholder="Buyer name *"
              className="rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm outline-none focus:border-emerald-500" />
            <input value={form.listingTitle} onChange={(e) => setForm({ ...form, listingTitle: e.target.value })} placeholder="Listing (e.g. iPhone 13)"
              className="rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm outline-none focus:border-emerald-500" />
            <textarea required value={form.buyerMessage} onChange={(e) => setForm({ ...form, buyerMessage: e.target.value })} placeholder="Paste their message * — e.g. Would you take $380?"
              rows={2} className="rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm outline-none focus:border-emerald-500 sm:col-span-2" />
            <input type="number" value={form.offerDollars} onChange={(e) => setForm({ ...form, offerDollars: e.target.value })} placeholder="Their offer $ (optional)"
              className="rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm outline-none focus:border-emerald-500" />
            <input type="number" required value={form.askingDollars} onChange={(e) => setForm({ ...form, askingDollars: e.target.value })} placeholder="Your asking price $ *"
              className="rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm outline-none focus:border-emerald-500" />
            <button className="rounded-xl bg-slate-900 py-2.5 text-sm font-bold text-white hover:bg-slate-700 sm:col-span-2">Add & select</button>
          </form>
        </Card>
      )}

      {loading ? (
        <div className="grid gap-4 lg:grid-cols-3">
          <Skeleton className="h-96" />
          <Skeleton className="h-96 lg:col-span-2" />
        </div>
      ) : negos.length === 0 ? (
        <EmptyState
          icon={<MessageCircleOff size={26} />}
          title="No buyer conversations yet"
          desc="When hagglers message you on any marketplace, paste their message here and the AI will craft the perfect reply."
          action={<button onClick={() => setShowNew(true)} className="rounded-xl bg-emerald-600 px-5 py-2.5 text-sm font-bold text-white">Add your first buyer</button>}
        />
      ) : (
        <div className="grid gap-4 lg:grid-cols-3">
          {/* list */}
          <div className="space-y-2 lg:max-h-[70vh] lg:overflow-y-auto lg:pr-1">
            {negos.map((n) => (
              <button key={n.id} onClick={() => { setSelectedId(n.id); setAiMeta(null); }}
                className={cn("w-full rounded-2xl border p-4 text-left transition",
                  selectedId === n.id ? "border-emerald-300 bg-emerald-50/50 shadow-md" : "border-slate-200 bg-white hover:border-slate-300")}>
                <div className="flex items-center justify-between gap-2">
                  <p className="truncate text-sm font-bold">{n.buyerName}</p>
                  <span className={cn("rounded-full px-2 py-0.5 text-[10px] font-bold ring-1", STATUS_COLORS[n.status])}>{n.status}</span>
                </div>
                <p className="mt-1 line-clamp-2 text-xs text-slate-500">“{n.buyerMessage}”</p>
                <div className="mt-2 flex items-center gap-2 text-[11px] font-bold">
                  {n.offerPrice ? (
                    <span className="rounded-md bg-amber-50 px-2 py-0.5 text-amber-700 ring-1 ring-amber-200">Offer {formatMoney(n.offerPrice)}</span>
                  ) : (
                    <span className="rounded-md bg-slate-100 px-2 py-0.5 text-slate-500">No offer yet</span>
                  )}
                  <span className="text-slate-400">Ask {formatMoney(n.askingPrice)}</span>
                </div>
              </button>
            ))}
          </div>

          {/* detail */}
          <div className="lg:col-span-2">
            {selected ? (
              <Card className="p-5 sm:p-6">
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div>
                    <h3 className="font-bold">{selected.buyerName}</h3>
                    <p className="text-xs text-slate-500">Re: {selected.listingTitle || "your listing"} · Asking {formatMoney(selected.askingPrice)}</p>
                  </div>
                  <div className="flex gap-1.5">
                    {(["new", "countered", "accepted", "declined"] as const).map((s) => (
                      <button key={s} onClick={() => setStatus(selected, s)}
                        className={cn("rounded-lg px-2.5 py-1.5 text-[11px] font-bold capitalize ring-1 transition",
                          selected.status === s ? "bg-slate-900 text-white ring-slate-900" : "bg-white text-slate-500 ring-slate-200 hover:bg-slate-50")}>
                        {s}
                      </button>
                    ))}
                    <button onClick={() => remove(selected.id)} className="rounded-lg px-2.5 py-1.5 text-rose-500 ring-1 ring-slate-200 hover:bg-rose-50" aria-label="Delete">
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>

                <div className="mt-4 max-w-[85%] rounded-2xl rounded-tl-md bg-slate-100 p-3.5">
                  <p className="text-[11px] font-bold text-slate-400">{selected.buyerName.toUpperCase()}</p>
                  <p className="mt-1 text-sm leading-relaxed">{selected.buyerMessage}</p>
                  {selected.offerPrice && (
                    <p className="mt-2 inline-block rounded-lg bg-white px-2.5 py-1 text-xs font-bold text-amber-700 ring-1 ring-amber-200">
                      💰 Offer: {formatMoney(selected.offerPrice)} ({Math.round((selected.offerPrice / Math.max(selected.askingPrice, 1)) * 100)}% of asking)
                    </p>
                  )}
                </div>

                <div className="mt-4">
                  <div className="flex flex-wrap items-center gap-2">
                    <p className="flex items-center gap-1.5 text-sm font-bold"><Sparkles size={15} className="text-indigo-600" /> AI suggested reply</p>
                    <div className="flex gap-1">
                      {TONES.map((t) => (
                        <button key={t} onClick={() => generate(selected, t)}
                          className={cn("rounded-full px-2.5 py-1 text-[11px] font-bold capitalize ring-1", selected.tone === t ? "bg-indigo-600 text-white ring-indigo-600" : "bg-white text-slate-500 ring-slate-200 hover:bg-slate-50")}>
                          {t}
                        </button>
                      ))}
                    </div>
                  </div>
                  {generating ? (
                    <p className="mt-3 flex items-center gap-2 rounded-2xl bg-indigo-50/60 p-4 text-sm text-indigo-700">
                      <Loader2 size={16} className="animate-spin" /> Crafting the perfect {selected.tone} reply…
                    </p>
                  ) : selected.suggestedReply ? (
                    <div className="mt-3 animate-fadeUp">
                      <div className="rounded-2xl rounded-tr-md bg-gradient-to-br from-indigo-600 to-violet-600 p-4 text-white shadow-lg">
                        <p className="text-sm leading-relaxed">{selected.suggestedReply}</p>
                      </div>
                      <div className="mt-2 flex flex-wrap gap-2">
                        <CopyButton text={selected.suggestedReply} label="Copy reply" small />
                        <button onClick={() => generate(selected)} className="inline-flex items-center gap-1.5 rounded-lg bg-white px-3 py-1.5 text-xs font-bold text-slate-700 ring-1 ring-slate-200 hover:bg-slate-50">
                          <Send size={13} /> Regenerate
                        </button>
                      </div>
                    </div>
                  ) : (
                    <button onClick={() => generate(selected)} className="mt-3 inline-flex items-center gap-2 rounded-xl bg-indigo-600 px-5 py-2.5 text-sm font-bold text-white hover:bg-indigo-700">
                      <Sparkles size={15} /> Generate reply
                    </button>
                  )}
                  {aiMeta && (
                    <div className="mt-3 rounded-xl bg-slate-50 p-3.5 animate-fadeUp">
                      <p className={cn("text-xs font-bold", verdictLabel[aiMeta.verdict]?.c)}>{verdictLabel[aiMeta.verdict]?.t}</p>
                      {aiMeta.verdict.startsWith("counter") && (
                        <p className="mt-1 text-xs text-slate-600">Suggested counter: <b>{formatMoney(aiMeta.counterCents)}</b></p>
                      )}
                      <ul className="mt-1.5 space-y-1">
                        {aiMeta.tips.map((t, i) => <li key={i} className="text-xs text-slate-500">• {t}</li>)}
                      </ul>
                    </div>
                  )}
                </div>
              </Card>
            ) : (
              <Card className="grid place-items-center p-16 text-center">
                <MessagesSquare size={28} className="text-slate-300" />
                <p className="mt-2 text-sm font-bold text-slate-500">Select a conversation</p>
              </Card>
            )}
          </div>
        </div>
      )}
      <Toast message={toast} />
    </div>
  );
}
