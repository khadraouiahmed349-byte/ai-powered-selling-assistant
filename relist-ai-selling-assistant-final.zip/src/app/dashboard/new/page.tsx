"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import {
  Camera, Sparkles, Loader2, ArrowRight, ArrowLeft, Check, Tag,
  Gauge, ImagePlus, ClipboardCopy, Rocket, PartyPopper, ScanSearch,
} from "lucide-react";
import { Card, SectionTitle, Toast } from "@/components/ui";
import PhotoUploader from "@/components/PhotoUploader";
import CopyButton from "@/components/CopyButton";
import { CATEGORIES, CONDITIONS, MARKETPLACES, formatMoney, cn } from "@/lib/utils";

async function ai(action: string, payload: Record<string, unknown>) {
  const res = await fetch("/api/ai", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action, ...payload }) });
  return res.json();
}

const STEPS = [
  { id: 1, label: "Photos & AI scan", icon: Camera },
  { id: 2, label: "AI title & description", icon: Sparkles },
  { id: 3, label: "Price it right", icon: Tag },
  { id: 4, label: "Review & publish", icon: Rocket },
];

type Analysis = {
  product: string; brand: string; category: string; confidence: number;
  tags: string[]; detectedCondition: string; photoTips: string[]; specs: string[]; titleDraft: string;
};

export default function NewListingPage() {
  const router = useRouter();
  const [step, setStep] = useState(1);
  const [images, setImages] = useState<string[]>([]);
  const [hint, setHint] = useState("");
  const [analysis, setAnalysis] = useState<Analysis | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  const [title, setTitle] = useState("");
  const [titles, setTitles] = useState<string[]>([]);
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("Other");
  const [brand, setBrand] = useState("");
  const [condition, setCondition] = useState("Good");
  const [extras, setExtras] = useState("");
  const [originalDollars, setOriginalDollars] = useState("");
  const [priceDollars, setPriceDollars] = useState("");
  const [estimate, setEstimate] = useState<{ low: number; high: number; suggested: number; sellFast: number; reasoning: string[]; confidence: number } | null>(null);
  const [marketplaces, setMarketplaces] = useState<string[]>(["facebook", "ebay"]);
  const [score, setScore] = useState<{ score: number; checks: Array<{ label: string; passed: boolean; fix: string }> } | null>(null);
  const [createdId, setCreatedId] = useState<string | null>(null);
  const [publishing, setPublishing] = useState(false);

  const showToast = (m: string) => { setToast(m); setTimeout(() => setToast(null), 2200); };

  const runAnalysis = async () => {
    setBusy("analyze");
    try {
      const { result } = await ai("analyze", { hint, category, imageCount: images.length, fileName: hint, images });
      if (result) {
        setAnalysis(result);
        setCategory(result.category || "Other");
        setBrand(result.brand || "");
        setCondition(result.detectedCondition || "Good");
        if (!title) setTitle(result.titleDraft);
        showToast(`Identified: ${result.product} (${Math.round(result.confidence * 100)}%)`);
      }
    } finally { setBusy(null); }
  };

  const runGenerate = async () => {
    setBusy("generate");
    try {
      const { result } = await ai("generate", { productHint: hint || analysis?.product || title, category, condition, brand, extras });
      if (result) {
        setTitles(result.titles);
        setTitle(result.titles[0]);
        setDescription(result.description);
        setCategory(result.category);
        if (result.brand && !brand) setBrand(result.brand);
        showToast("AI listing content generated ✨");
      }
    } finally { setBusy(null); }
  };

  const runEstimate = async () => {
    setBusy("estimate");
    try {
      const { result } = await ai("estimate", {
        category, condition,
        originalPriceCents: originalDollars ? Math.round(parseFloat(originalDollars) * 100) : null,
        hint: hint || title,
      });
      if (result) {
        setEstimate(result);
        setPriceDollars(String(result.suggested / 100));
      }
    } finally { setBusy(null); }
  };

  const runScore = async () => {
    setBusy("score");
    try {
      const { result } = await ai("score", {
        title, description,
        priceCents: Math.round(parseFloat(priceDollars || "0") * 100),
        imageCount: images.length, category, brand, condition,
      });
      if (result) setScore(result);
    } finally { setBusy(null); }
  };

  const publish = async (status: string) => {
    if (!title.trim()) { showToast("Add a title first"); return; }
    setPublishing(true);
    try {
      const res = await fetch("/api/listings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: title.trim(), description, category, brand, condition,
          price: Math.round(parseFloat(priceDollars || "0") * 100),
          originalPrice: originalDollars ? Math.round(parseFloat(originalDollars) * 100) : null,
          estimatedLow: estimate?.low ?? null, estimatedHigh: estimate?.high ?? null,
          suggestedPrice: estimate?.suggested ?? null,
          status, marketplaceTargets: marketplaces,
          seoKeywords: analysis?.tags ?? [], aiAnalysis: analysis ?? {}, images,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setCreatedId(data.listing.id);
      setStep(5);
    } catch {
      showToast("Publish failed — try again");
    } finally {
      setPublishing(false);
    }
  };

  const fullText = `${title}\n${priceDollars ? `$${priceDollars}` : ""} · ${condition} · ${category}\n\n${description}`;

  return (
    <div className="mx-auto max-w-4xl space-y-6 animate-fadeUp">
      <SectionTitle
        eyebrow="AI Listing Studio"
        title="Create a listing"
        desc="From photo to published in 4 guided steps"
      />

      {/* stepper */}
      <div className="flex items-center gap-1 overflow-x-auto rounded-2xl border border-slate-200 bg-white p-2 sm:gap-2">
        {STEPS.map((s) => {
          const done = step > s.id;
          const active = step === s.id;
          return (
            <button key={s.id} onClick={() => step < 5 && s.id < step && setStep(s.id)}
              className={cn("flex flex-1 items-center justify-center gap-2 rounded-xl px-3 py-2.5 text-xs font-bold transition sm:text-sm",
                active ? "bg-slate-900 text-white shadow-md" : done ? "bg-emerald-50 text-emerald-700" : "text-slate-400")}>
              {done ? <Check size={15} strokeWidth={3} /> : <s.icon size={15} />}
              <span className="hidden sm:inline">{s.label}</span>
              <span className="sm:hidden">{s.id}</span>
            </button>
          );
        })}
      </div>

      {step === 1 && (
        <Card className="p-5 sm:p-6">
          <h3 className="flex items-center gap-2 font-bold"><ImagePlus size={18} className="text-emerald-600" /> Step 1 — Upload photos & describe the item</h3>
          <p className="mt-1 text-sm text-slate-500">Add up to 8 photos. The more angles, the better the AI identification.</p>
          <div className="mt-4"><PhotoUploader images={images} onChange={setImages} /></div>
          <label className="mt-4 block text-xs font-bold text-slate-700">What is it? (a few words help AI a lot)</label>
          <div className="mt-1.5 flex gap-2">
            <input value={hint} onChange={(e) => setHint(e.target.value)} placeholder="e.g. iPhone 13 128GB, IKEA 3-seat sofa, Trek bike…"
              className="w-full rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100" />
            <button onClick={runAnalysis} disabled={busy === "analyze"}
              className="inline-flex shrink-0 items-center gap-1.5 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 px-4 py-3 text-sm font-bold text-white shadow-lg hover:opacity-95 disabled:opacity-60">
              {busy === "analyze" ? <Loader2 size={16} className="animate-spin" /> : <ScanSearch size={16} />}
              <span className="hidden sm:inline">AI scan</span>
            </button>
          </div>

          {analysis && (
            <div className="mt-4 rounded-2xl border border-violet-100 bg-gradient-to-br from-violet-50/70 to-indigo-50/50 p-4 animate-fadeUp">
              <p className="flex items-center gap-2 text-sm font-bold text-violet-900">
                <Sparkles size={15} /> AI identified: {analysis.product}
                <span className="rounded-full bg-violet-600 px-2 py-0.5 text-[11px] text-white">{Math.round(analysis.confidence * 100)}% confident</span>
              </p>
              <div className="mt-2.5 grid gap-3 sm:grid-cols-2">
                <div className="rounded-xl bg-white/80 p-3 text-xs">
                  <p className="font-bold text-slate-700">DETECTED DETAILS</p>
                  <p className="mt-1.5 text-slate-600">Brand: <b>{analysis.brand || "—"}</b> · Category: <b>{analysis.category}</b></p>
                  <p className="mt-1 text-slate-600">Likely condition: <b>{analysis.detectedCondition}</b></p>
                  <div className="mt-2 flex flex-wrap gap-1">
                    {analysis.tags.map((t) => <span key={t} className="rounded-md bg-violet-100 px-2 py-0.5 font-semibold text-violet-700">{t}</span>)}
                  </div>
                </div>
                <div className="rounded-xl bg-white/80 p-3 text-xs">
                  <p className="font-bold text-slate-700">📸 PHOTO TIPS</p>
                  <ul className="mt-1.5 space-y-1 text-slate-600">
                    {analysis.photoTips.map((t, i) => <li key={i}>• {t}</li>)}
                  </ul>
                </div>
              </div>
            </div>
          )}

          <div className="mt-5 flex justify-end">
            <button onClick={() => setStep(2)} className="inline-flex items-center gap-2 rounded-xl bg-slate-900 px-6 py-3 text-sm font-bold text-white hover:bg-slate-700">
              Continue <ArrowRight size={16} />
            </button>
          </div>
        </Card>
      )}

      {step === 2 && (
        <Card className="p-5 sm:p-6">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h3 className="flex items-center gap-2 font-bold"><Sparkles size={18} className="text-emerald-600" /> Step 2 — AI title & description</h3>
            <button onClick={runGenerate} disabled={busy === "generate"}
              className="inline-flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 px-4 py-2.5 text-sm font-bold text-white shadow-lg hover:opacity-95 disabled:opacity-60">
              {busy === "generate" ? <Loader2 size={15} className="animate-spin" /> : <Sparkles size={15} />} Generate with AI
            </button>
          </div>
          <div className="mt-4 grid gap-3 sm:grid-cols-3">
            <div>
              <label className="text-xs font-bold text-slate-500">Category</label>
              <select value={category} onChange={(e) => setCategory(e.target.value)} className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm outline-none focus:border-emerald-500">
                {CATEGORIES.map((c) => <option key={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs font-bold text-slate-500">Brand</label>
              <input value={brand} onChange={(e) => setBrand(e.target.value)} placeholder="Apple…" className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm outline-none focus:border-emerald-500" />
            </div>
            <div>
              <label className="text-xs font-bold text-slate-500">Condition</label>
              <select value={condition} onChange={(e) => setCondition(e.target.value)} className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm outline-none focus:border-emerald-500">
                {CONDITIONS.map((c) => <option key={c}>{c}</option>)}
              </select>
            </div>
          </div>
          <label className="mt-3 block text-xs font-bold text-slate-500">Extras / what's included (optional)</label>
          <input value={extras} onChange={(e) => setExtras(e.target.value)} placeholder="e.g. extra case, 2 chargers, receipt…"
            className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm outline-none focus:border-emerald-500" />

          {titles.length > 0 && (
            <div className="mt-4 space-y-1.5">
              <p className="text-[11px] font-bold uppercase tracking-wider text-slate-500">AI title options — click to use</p>
              {titles.map((t, i) => (
                <button key={i} onClick={() => setTitle(t)}
                  className={cn("block w-full rounded-xl px-4 py-2.5 text-left text-sm font-semibold ring-1 transition",
                    title === t ? "bg-emerald-50 ring-emerald-400" : "bg-white ring-slate-200 hover:ring-emerald-300")}>
                  {t}
                </button>
              ))}
            </div>
          )}

          <label className="mt-4 block text-xs font-bold text-slate-700">Title ({title.length}/80 sweet spot)</label>
          <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="AI will write this — or type your own"
            className="mt-1.5 w-full rounded-xl border border-slate-200 px-4 py-3 text-sm font-semibold outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100" />
          <label className="mt-3 block text-xs font-bold text-slate-700">Description ({description.length} chars)</label>
          <textarea value={description} rows={9} onChange={(e) => setDescription(e.target.value)} placeholder="Hit 'Generate with AI' and watch the magic…"
            className="mt-1.5 w-full rounded-xl border border-slate-200 px-4 py-3 text-sm leading-relaxed outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100" />
          {description && (
            <div className="mt-2 flex gap-2">
              <CopyButton text={title} label="Copy title" small />
              <CopyButton text={description} label="Copy description" small />
            </div>
          )}
          <div className="mt-5 flex justify-between">
            <button onClick={() => setStep(1)} className="inline-flex items-center gap-2 rounded-xl px-4 py-3 text-sm font-bold text-slate-600 hover:bg-slate-100">
              <ArrowLeft size={16} /> Back
            </button>
            <button onClick={() => setStep(3)} disabled={!title.trim()} className="inline-flex items-center gap-2 rounded-xl bg-slate-900 px-6 py-3 text-sm font-bold text-white hover:bg-slate-700 disabled:opacity-40">
              Continue <ArrowRight size={16} />
            </button>
          </div>
        </Card>
      )}

      {step === 3 && (
        <Card className="p-5 sm:p-6">
          <h3 className="flex items-center gap-2 font-bold"><Tag size={18} className="text-amber-600" /> Step 3 — Price it right</h3>
          <p className="mt-1 text-sm text-slate-500">AI estimates a fair range from category, condition and retail price.</p>
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            <div>
              <label className="text-xs font-bold text-slate-700">Original retail price ($, optional)</label>
              <input type="number" min="0" value={originalDollars} onChange={(e) => setOriginalDollars(e.target.value)} placeholder="e.g. 799"
                className="mt-1.5 w-full rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-emerald-500" />
            </div>
            <div>
              <label className="text-xs font-bold text-slate-700">Your asking price ($)</label>
              <input type="number" min="0" value={priceDollars} onChange={(e) => setPriceDollars(e.target.value)} placeholder="e.g. 429"
                className="mt-1.5 w-full rounded-xl border border-slate-200 px-4 py-3 text-sm font-bold outline-none focus:border-emerald-500" />
            </div>
          </div>
          <button onClick={runEstimate} disabled={busy === "estimate"}
            className="mt-3 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-slate-900 px-4 py-3 text-sm font-bold text-white hover:bg-slate-700 disabled:opacity-60">
            {busy === "estimate" ? <Loader2 size={16} className="animate-spin" /> : <Tag size={16} />} Get AI price estimate
          </button>
          {estimate && (
            <div className="mt-4 rounded-2xl bg-gradient-to-br from-amber-50 to-orange-50/60 p-4 ring-1 ring-amber-100 animate-fadeUp">
              <div className="grid grid-cols-3 gap-2 text-center">
                <div className="rounded-xl bg-white/80 p-3"><p className="text-[10px] font-bold text-slate-500">FAIR RANGE</p><p className="mt-1 text-base font-extrabold sm:text-lg">{formatMoney(estimate.low)}–{formatMoney(estimate.high)}</p></div>
                <div className="rounded-xl bg-emerald-600 p-3 text-white shadow-lg"><p className="text-[10px] font-bold text-emerald-100">✨ SUGGESTED</p><p className="mt-1 text-base font-extrabold sm:text-lg">{formatMoney(estimate.suggested)}</p></div>
                <div className="rounded-xl bg-white/80 p-3"><p className="text-[10px] font-bold text-slate-500">LOWER-PRICE SCENARIO</p><p className="mt-1 text-base font-extrabold sm:text-lg">{formatMoney(estimate.sellFast)}</p></div>
              </div>
              <div className="mt-2.5 flex gap-2">
                {[["Use suggested", estimate.suggested], ["Sell fast", estimate.sellFast]].map(([label, val]) => (
                  <button key={label as string} onClick={() => setPriceDollars(String((val as number) / 100))}
                    className="flex-1 rounded-xl bg-white py-2.5 text-xs font-bold ring-1 ring-amber-200 hover:bg-amber-50">
                    {label} · {formatMoney(val as number)}
                  </button>
                ))}
              </div>
              <ul className="mt-3 space-y-1">
                {estimate.reasoning.map((r, i) => <li key={i} className="text-xs text-slate-600">• {r}</li>)}
              </ul>
            </div>
          )}
          <div className="mt-5 flex justify-between">
            <button onClick={() => setStep(2)} className="inline-flex items-center gap-2 rounded-xl px-4 py-3 text-sm font-bold text-slate-600 hover:bg-slate-100">
              <ArrowLeft size={16} /> Back
            </button>
            <button onClick={() => { setStep(4); setTimeout(runScore, 100); }} className="inline-flex items-center gap-2 rounded-xl bg-slate-900 px-6 py-3 text-sm font-bold text-white hover:bg-slate-700">
              Continue <ArrowRight size={16} />
            </button>
          </div>
        </Card>
      )}

      {step === 4 && (
        <div className="space-y-4">
          <Card className="p-5 sm:p-6">
            <h3 className="flex items-center gap-2 font-bold"><Gauge size={18} className="text-teal-600" /> Step 4 — Quality check & publish</h3>
            <div className="mt-4 overflow-hidden rounded-2xl border border-slate-200">
              <div className="grid sm:grid-cols-2">
                <div className="aspect-[16/10] bg-slate-100 sm:aspect-auto sm:min-h-[220px]">
                  {images[0] ? <img src={images[0]} alt="cover" className="h-full w-full object-cover" /> : <span className="grid h-full min-h-[180px] place-items-center text-5xl">📦</span>}
                </div>
                <div className="p-4">
                  <p className="text-[11px] font-bold text-slate-400">{category} · {condition}{brand ? ` · ${brand}` : ""} · {images.length} photos</p>
                  <h4 className="mt-1 line-clamp-2 text-[15px] font-bold leading-snug">{title || "Untitled listing"}</h4>
                  <p className="mt-1 text-xl font-extrabold">{priceDollars ? `$${priceDollars}` : "No price"}</p>
                  <p className="mt-1.5 line-clamp-3 text-xs leading-relaxed text-slate-500">{description || "No description yet."}</p>
                </div>
              </div>
            </div>

            <div className="mt-4 rounded-2xl bg-slate-50 p-4">
              <div className="flex items-center justify-between">
                <p className="text-sm font-bold">Listing quality score</p>
                <button onClick={runScore} disabled={busy === "score"} className="rounded-lg bg-white px-3 py-1.5 text-xs font-bold ring-1 ring-slate-200 hover:bg-slate-50">
                  {busy === "score" ? "Checking…" : "Re-check"}
                </button>
              </div>
              {busy === "score" ? (
                <p className="mt-2 flex items-center gap-2 text-sm text-slate-500"><Loader2 size={15} className="animate-spin" /> AI is grading your listing…</p>
              ) : score ? (
                <div className="mt-2">
                  <div className="flex items-center gap-3">
                    <div className="h-2.5 flex-1 overflow-hidden rounded-full bg-slate-200">
                      <div className={cn("h-full rounded-full transition-all", score.score >= 80 ? "bg-emerald-500" : score.score >= 60 ? "bg-lime-500" : score.score >= 40 ? "bg-amber-500" : "bg-rose-500")} style={{ width: `${score.score}%` }} />
                    </div>
                    <span className="text-lg font-extrabold">{score.score}</span>
                  </div>
                  <ul className="mt-2.5 grid gap-1 sm:grid-cols-2">
                    {score.checks.map((c, i) => (
                      <li key={i} className="flex items-start gap-1.5 text-xs">
                        {c.passed ? <Check size={14} className="mt-0.5 shrink-0 text-emerald-600" strokeWidth={3} /> : <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-amber-500" />}
                        <span className={c.passed ? "text-slate-500" : "font-semibold text-slate-800"}>{c.passed ? c.label : c.fix}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              ) : (
                <p className="mt-2 text-xs text-slate-500">Run the check to grade this listing before publishing.</p>
              )}
            </div>

            <p className="mt-4 text-xs font-bold text-slate-500">PUBLISH TARGETS</p>
            <div className="mt-2 flex flex-wrap gap-1.5">
              {MARKETPLACES.map((m) => {
                const on = marketplaces.includes(m.id);
                return (
                  <button key={m.id} onClick={() => setMarketplaces(on ? marketplaces.filter((x) => x !== m.id) : [...marketplaces, m.id])}
                    className={cn("rounded-full px-3.5 py-1.5 text-xs font-bold ring-1 transition", on ? "bg-emerald-600 text-white ring-emerald-600" : "bg-white text-slate-600 ring-slate-200 hover:ring-slate-300")}>
                    {m.name}
                  </button>
                );
              })}
            </div>

            <div className="mt-4 flex items-center gap-2 rounded-xl bg-indigo-50/70 p-3 ring-1 ring-indigo-100">
              <ClipboardCopy size={16} className="shrink-0 text-indigo-600" />
              <p className="flex-1 text-xs text-indigo-900">Copy everything with one click after publishing — paste straight into any marketplace.</p>
              <CopyButton text={fullText} label="Copy listing" small />
            </div>

            <div className="mt-5 flex flex-wrap justify-between gap-2">
              <button onClick={() => setStep(3)} className="inline-flex items-center gap-2 rounded-xl px-4 py-3 text-sm font-bold text-slate-600 hover:bg-slate-100">
                <ArrowLeft size={16} /> Back
              </button>
              <div className="flex gap-2">
                <button onClick={() => publish("draft")} disabled={publishing} className="rounded-xl bg-white px-5 py-3 text-sm font-bold text-slate-700 ring-1 ring-slate-300 hover:bg-slate-50 disabled:opacity-50">
                  {publishing ? "Saving…" : "Save as draft"}
                </button>
                <button onClick={() => publish("active")} disabled={publishing} className="inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-6 py-3 text-sm font-bold text-white shadow-lg shadow-emerald-600/25 hover:bg-emerald-700 disabled:opacity-50">
                  {publishing ? <Loader2 size={16} className="animate-spin" /> : <Rocket size={16} />} Publish now
                </button>
              </div>
            </div>
          </Card>
        </div>
      )}

      {step === 5 && (
        <Card className="p-10 text-center">
          <span className="mx-auto grid h-16 w-16 place-items-center rounded-3xl bg-emerald-50 text-emerald-600"><PartyPopper size={30} /></span>
          <h3 className="mt-4 text-2xl font-extrabold">Listing created! 🎉</h3>
          <p className="mx-auto mt-2 max-w-md text-sm text-slate-500">Your AI-powered listing is ready. Copy it to any marketplace or keep polishing it in the editor.</p>
          <div className="mt-3 flex justify-center gap-2">
            <CopyButton text={fullText} label="Copy full listing" />
          </div>
          <div className="mt-5 flex flex-wrap justify-center gap-2">
            <button onClick={() => createdId && router.push(`/dashboard/listings/${createdId}`)} className="rounded-xl bg-slate-900 px-6 py-3 text-sm font-bold text-white hover:bg-slate-700">
              Open listing
            </button>
            <button onClick={() => { setStep(1); setImages([]); setHint(""); setAnalysis(null); setTitle(""); setTitles([]); setDescription(""); setEstimate(null); setScore(null); setPriceDollars(""); setCreatedId(null); }} className="rounded-xl bg-white px-6 py-3 text-sm font-bold ring-1 ring-slate-300 hover:bg-slate-50">
              Create another
            </button>
            <button onClick={() => router.push("/dashboard/listings")} className="rounded-xl bg-emerald-600 px-6 py-3 text-sm font-bold text-white hover:bg-emerald-700">
              View all listings
            </button>
          </div>
        </Card>
      )}
      <Toast message={toast} />
    </div>
  );
}
