export default function Page() {
  return <main className="min-h-screen bg-slate-50 px-5 py-12 text-slate-900"><article className="mx-auto max-w-3xl rounded-3xl border border-slate-200 bg-white p-8 shadow-sm"><h1 className="text-3xl font-black">Terms of Service</h1><div className="mt-6 whitespace-pre-line text-sm leading-7 text-slate-600">These terms are a starting template and must be reviewed for your business and jurisdiction before use.

ReList AI provides tools for drafting and optimizing used-item listings. Users remain responsible for the accuracy and legality of listings, prices, product claims, marketplace compliance and transactions. AI output should be reviewed before publication and is not a guarantee of a sale or market price.</div></article></main>;
}
