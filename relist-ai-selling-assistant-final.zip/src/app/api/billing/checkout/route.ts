import { NextResponse } from "next/server";
import { getSessionUserId } from "@/lib/auth";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET(req: Request) {
  const userId = await getSessionUserId();
  if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  if (new URL(req.url).searchParams.get("plan") !== "pro") return NextResponse.json({ error: "Unknown plan" }, { status: 400 });
  const apiKey = process.env.LEMONSQUEEZY_API_KEY, storeId = process.env.LEMONSQUEEZY_STORE_ID, variantId = process.env.LEMONSQUEEZY_PRO_VARIANT_ID;
  if (!apiKey || !storeId || !variantId) return NextResponse.json({ error: "Billing is not configured yet." }, { status: 503 });
  const user = (await db.select({ email: users.email, name: users.name }).from(users).where(eq(users.id, userId)).limit(1))[0];
  const response = await fetch("https://api.lemonsqueezy.com/v1/checkouts", { method: "POST", headers: { Accept: "application/vnd.api+json", "Content-Type": "application/vnd.api+json", Authorization: `Bearer ${apiKey}` }, body: JSON.stringify({ data: { type: "checkouts", attributes: { checkout_data: { email: user?.email, name: user?.name, custom: { user_id: userId } }, product_options: { redirect_url: `${process.env.NEXT_PUBLIC_APP_URL ?? new URL(req.url).origin}/dashboard` } }, relationships: { store: { data: { type: "stores", id: storeId } }, variant: { data: { type: "variants", id: variantId } } } } }) });
  if (!response.ok) return NextResponse.json({ error: "Could not create checkout." }, { status: 502 });
  const json = await response.json();
  const url = json?.data?.attributes?.url;
  if (!url) return NextResponse.json({ error: "Checkout URL missing." }, { status: 502 });
  return NextResponse.redirect(url);
}
