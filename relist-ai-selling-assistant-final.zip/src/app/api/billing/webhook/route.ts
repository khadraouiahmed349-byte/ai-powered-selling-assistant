import { NextResponse } from "next/server";
import { createHmac, timingSafeEqual } from "node:crypto";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";

function validSignature(raw: string, signature: string | null) {
  const secret = process.env.LEMONSQUEEZY_WEBHOOK_SECRET;
  if (!secret || !signature) return false;
  const digest = createHmac("sha256", secret).update(raw).digest("hex");
  const a = Buffer.from(digest, "utf8"), b = Buffer.from(signature, "utf8");
  return a.length === b.length && timingSafeEqual(a, b);
}

export async function POST(req: Request) {
  const raw = await req.text();
  if (!validSignature(raw, req.headers.get("x-signature"))) return NextResponse.json({ error: "Invalid signature" }, { status: 401 });
  try {
    const body = JSON.parse(raw) as { meta?: { custom_data?: { userId?: string } }, data?: { id?: string, attributes?: { status?: string } } };
    const userId = body.meta?.custom_data?.userId;
    if (!userId) return NextResponse.json({ ok: true });
    const status = body.data?.attributes?.status ?? "active";
    const active = ["active", "on_trial"].includes(status);
    await db.update(users).set({ plan: active ? "pro" : "free", subscriptionStatus: status, lemonSubscriptionId: body.data?.id ?? null }).where(eq(users.id, userId));
    return NextResponse.json({ ok: true });
  } catch { return NextResponse.json({ error: "Invalid payload" }, { status: 400 }); }
}
