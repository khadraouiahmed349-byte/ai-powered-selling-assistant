import { NextResponse } from "next/server";
import { db } from "@/db";
import { negotiations } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { getSessionUserId } from "@/lib/auth";

export async function GET() {
  const userId = await getSessionUserId();
  if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const rows = await db.select().from(negotiations).where(eq(negotiations.userId, userId)).orderBy(desc(negotiations.updatedAt));
  return NextResponse.json({ negotiations: rows });
}

export async function POST(req: Request) {
  const userId = await getSessionUserId();
  if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  try {
    const body = await req.json();
    if (!body.buyerName?.trim() || !body.buyerMessage?.trim()) {
      return NextResponse.json({ error: "Buyer name and message are required." }, { status: 400 });
    }
    const [row] = await db.insert(negotiations).values({
      userId,
      listingId: body.listingId || null,
      listingTitle: body.listingTitle || "",
      buyerName: body.buyerName.trim(),
      buyerMessage: body.buyerMessage.trim(),
      offerPrice: body.offerPrice ?? null,
      askingPrice: body.askingPrice ?? 0,
      status: "new",
      suggestedReply: body.suggestedReply || "",
      tone: body.tone || "friendly",
    }).returning();
    return NextResponse.json({ negotiation: row }, { status: 201 });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "Failed to create negotiation." }, { status: 500 });
  }
}
