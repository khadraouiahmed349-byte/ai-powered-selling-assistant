import { NextResponse } from "next/server";
import { db } from "@/db";
import { negotiations } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { getSessionUserId } from "@/lib/auth";

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const userId = await getSessionUserId();
  if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await params;
  try {
    const body = await req.json();
    const patch: Record<string, unknown> = {};
    for (const f of ["buyerName", "buyerMessage", "offerPrice", "askingPrice", "status", "suggestedReply", "tone", "listingTitle", "listingId"]) {
      if (body[f] !== undefined) patch[f] = body[f];
    }
    patch.updatedAt = new Date();
    const [updated] = await db.update(negotiations).set(patch).where(and(eq(negotiations.id, id), eq(negotiations.userId, userId))).returning();
    if (!updated) return NextResponse.json({ error: "Not found" }, { status: 404 });
    return NextResponse.json({ negotiation: updated });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "Update failed." }, { status: 500 });
  }
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const userId = await getSessionUserId();
  if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await params;
  await db.delete(negotiations).where(and(eq(negotiations.id, id), eq(negotiations.userId, userId)));
  return NextResponse.json({ ok: true });
}
