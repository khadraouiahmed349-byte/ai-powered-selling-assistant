import { NextResponse } from "next/server";
import { db } from "@/db";
import { listings, negotiations } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getSessionUserId } from "@/lib/auth";

export async function GET() {
  const userId = await getSessionUserId();
  if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const ls = await db.select().from(listings).where(eq(listings.userId, userId));
  const ng = await db.select().from(negotiations).where(eq(negotiations.userId, userId));
  const active = ls.filter((l) => l.status === "active");
  const sold = ls.filter((l) => l.status === "sold");
  const totalViews = ls.reduce((s, l) => s + (l.views ?? 0), 0);
  const totalInquiries = ls.reduce((s, l) => s + (l.inquiries ?? 0), 0) + ng.length;
  const revenue = sold.reduce((s, l) => s + (l.price ?? 0), 0);
  const inventoryValue = active.reduce((s, l) => s + (l.price ?? 0), 0);
  const avgScore = ls.length ? Math.round(ls.reduce((s, l) => s + (l.qualityScore ?? 0), 0) / ls.length) : 0;
  return NextResponse.json({
    stats: {
      total: ls.length, active: active.length, draft: ls.filter((l) => l.status === "draft").length,
      sold: sold.length, totalViews, totalInquiries, revenue, inventoryValue, avgScore,
      openNegotiations: ng.filter((n) => n.status === "new").length,
    },
  });
}
