import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { hashPassword, createSession } from "@/lib/auth";
import { clientKey, rateLimit } from "@/lib/rate-limit";
import { email, password as validatePassword, text } from "@/lib/validation";

export async function POST(req: Request) {
  const rl = rateLimit(clientKey(req, "signup"), 5, 60_000);
  if (!rl.ok) return NextResponse.json({ error: "Too many signup attempts." }, { status: 429 });
  try {
    const body = await req.json();
    const name = text(body.name, 100); const normalizedEmail = email(body.email); const password = typeof body.password === "string" ? body.password : ""; const shopName = text(body.shopName, 120);
    const validPassword = validatePassword(password);
    if (!name || !normalizedEmail || !validPassword) {
      return NextResponse.json({ error: "Name, email and password are required." }, { status: 400 });
    }

    const existing = await db.select().from(users).where(eq(users.email, normalizedEmail)).limit(1);
    if (existing[0]) {
      return NextResponse.json({ error: "An account with this email already exists." }, { status: 409 });
    }
    const colors = ["emerald", "violet", "amber", "sky", "rose"];
    const avatarColor = colors[Math.floor(Math.random() * colors.length)];
    const [user] = await db.insert(users).values({
      name: name.trim(),
      email: normalizedEmail,
      passwordHash: await hashPassword(validPassword),
      shopName: shopName || null,
      avatarColor,
    }).returning();
    await createSession(user.id);
    const { passwordHash: _p, ...safe } = user;
    return NextResponse.json({ user: safe });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "Signup failed. Try again." }, { status: 500 });
  }
}
