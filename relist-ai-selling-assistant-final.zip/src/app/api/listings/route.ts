import { NextResponse } from "next/server";
import { db } from "@/db";
import { listings, listingImages } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { getSessionUserId } from "@/lib/auth";
import { qualityScore } from "@/lib/ai";
import { moneyCents, enumValue, safeImageUrl, stringArray, text } from "@/lib/validation";

export async function GET(req: Request) {
  const userId = await getSessionUserId();
  if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { searchParams } = new URL(req.url);
  const status = searchParams.get("status");
  const q = searchParams.get("q")?.toLowerCase() ?? "";

  let rows = await db.select().from(listings).where(eq(listings.userId, userId)).orderBy(desc(listings.updatedAt));
  if (status && status !== "all") rows = rows.filter((r) => r.status === status);
  if (q) rows = rows.filter((r) => (r.title + " " + r.description + " " + r.category + " " + r.brand).toLowerCase().includes(q));

  // attach images
  const withImages = await Promise.all(
    rows.map(async (l) => {
      const imgs = await db.select().from(listingImages).where(eq(listingImages.listingId, l.id));
      imgs.sort((a, b) => (a.sortOrder - b.sortOrder) || (a.isPrimary ? -1 : 1));
      return { ...l, images: imgs };
    })
  );
  return NextResponse.json({ listings: withImages });
}

export async function POST(req: Request) {
  const userId = await getSessionUserId();
  if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  try {
    const body = await req.json();
    const {
      title, description = "", category = "Other", brand = "", condition = "Good",
      price = 0, originalPrice = null, estimatedLow = null, estimatedHigh = null,
      suggestedPrice = null, status = "draft", marketplaceTargets = [],
      seoKeywords = [], aiAnalysis = {}, images = [] as string[],
    } = body;
    const cleanTitle = text(title, 200);
    const cleanDescription = text(description, 5000);
    const cleanCategory = text(category, 100, "Other");
    const cleanBrand = text(brand, 100);
    const cleanCondition = enumValue(condition, ["Like New", "Excellent", "Good", "Fair", "For Parts"] as const, "Good");
    const cleanStatus = enumValue(status, ["draft", "active", "sold", "archived"] as const, "draft");
    const cleanImages = Array.isArray(images) ? images.slice(0, 8).map(safeImageUrl).filter(Boolean) as string[] : [];
    const cleanPrice = moneyCents(price) ?? 0;
    if (!cleanTitle) return NextResponse.json({ error: "Title is required." }, { status: 400 });
    if (Array.isArray(images) && images.length !== cleanImages.length) return NextResponse.json({ error: "Only HTTPS image URLs are allowed after upload." }, { status: 400 });

    const qs = qualityScore({ title: cleanTitle, description: cleanDescription, priceCents: cleanPrice, imageCount: cleanImages.length, category: cleanCategory, brand: cleanBrand, condition: cleanCondition, keywords: stringArray(seoKeywords), });

    const [row] = await db.insert(listings).values({
      userId, title: cleanTitle, description: cleanDescription, category: cleanCategory, brand: cleanBrand, condition: cleanCondition,
      price: cleanPrice, originalPrice: moneyCents(originalPrice),
      estimatedLow: moneyCents(estimatedLow), estimatedHigh: moneyCents(estimatedHigh), suggestedPrice: moneyCents(suggestedPrice),
      status: cleanStatus, qualityScore: qs.score,
      marketplaceTargets: stringArray(marketplaceTargets), seoKeywords: stringArray(seoKeywords),
      aiAnalysis: aiAnalysis && typeof aiAnalysis === "object" && !Array.isArray(aiAnalysis) ? aiAnalysis : {},
    }).returning();

    for (let i = 0; i < cleanImages.length; i++) {
      await db.insert(listingImages).values({ listingId: row.id, url: cleanImages[i], isPrimary: i === 0, sortOrder: i });
    }
    const imgs = await db.select().from(listingImages).where(eq(listingImages.listingId, row.id));
    return NextResponse.json({ listing: { ...row, images: imgs } }, { status: 201 });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "Failed to create listing." }, { status: 500 });
  }
}
