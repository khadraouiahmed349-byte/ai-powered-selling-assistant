import { NextResponse } from "next/server";
import { db } from "@/db";
import { listings, listingImages } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { getSessionUserId } from "@/lib/auth";
import { qualityScore } from "@/lib/ai";
import { moneyCents, enumValue, safeImageUrl, stringArray, text } from "@/lib/validation";

async function owned(id: string, userId: string) {
  const rows = await db.select().from(listings).where(and(eq(listings.id, id), eq(listings.userId, userId))).limit(1);
  return rows[0] ?? null;
}

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const userId = await getSessionUserId();
  if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await params;
  const row = await owned(id, userId);
  if (!row) return NextResponse.json({ error: "Not found" }, { status: 404 });
  const imgs = await db.select().from(listingImages).where(eq(listingImages.listingId, id));
  imgs.sort((a, b) => a.sortOrder - b.sortOrder);
  return NextResponse.json({ listing: { ...row, images: imgs } });
}

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const userId = await getSessionUserId();
  if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await params;
  const row = await owned(id, userId);
  if (!row) return NextResponse.json({ error: "Not found" }, { status: 404 });
  try {
    const body = await req.json();
    const patch: Record<string, unknown> = {};
    if (body.title !== undefined) patch.title = text(body.title, 200);
    if (body.description !== undefined) patch.description = text(body.description, 5000);
    if (body.category !== undefined) patch.category = text(body.category, 100, "Other");
    if (body.brand !== undefined) patch.brand = text(body.brand, 100);
    if (body.condition !== undefined) patch.condition = enumValue(body.condition, ["Like New", "Excellent", "Good", "Fair", "For Parts"] as const, "Good");
    for (const f of ["price", "originalPrice", "estimatedLow", "estimatedHigh", "suggestedPrice", "views", "inquiries"]) {
      if (body[f] !== undefined) { const n = moneyCents(body[f]); if (n === null) return NextResponse.json({ error: `Invalid ${f}.` }, { status: 400 }); patch[f] = n; }
    }
    if (body.status !== undefined) patch.status = enumValue(body.status, ["draft", "active", "sold", "archived"] as const, "draft");
    if (body.marketplaceTargets !== undefined) patch.marketplaceTargets = stringArray(body.marketplaceTargets);
    if (body.seoKeywords !== undefined) patch.seoKeywords = stringArray(body.seoKeywords);
    if (body.aiAnalysis !== undefined) patch.aiAnalysis = body.aiAnalysis && typeof body.aiAnalysis === "object" && !Array.isArray(body.aiAnalysis) ? body.aiAnalysis : {};

    // recompute quality score with merged values
    const merged = { ...row, ...patch } as typeof row;
    let imageCount = (await db.select().from(listingImages).where(eq(listingImages.listingId, id))).length;
    if (body.images !== undefined && Array.isArray(body.images)) {
      // replace images
      await db.delete(listingImages).where(eq(listingImages.listingId, id));
      const imgs = body.images.slice(0, 8).map(safeImageUrl).filter(Boolean) as string[];
      if (imgs.length !== Math.min(body.images.length, 8)) return NextResponse.json({ error: "Only HTTPS image URLs are allowed after upload." }, { status: 400 });
      for (let i = 0; i < imgs.length; i++) {
        await db.insert(listingImages).values({ listingId: id, url: imgs[i], isPrimary: i === 0, sortOrder: i });
      }
      imageCount = imgs.length;
    }
    const qs = qualityScore({
      title: String(merged.title ?? ""), description: String(merged.description ?? ""),
      priceCents: Number(merged.price ?? 0), imageCount,
      category: String(merged.category ?? "Other"), brand: String(merged.brand ?? ""),
      condition: String(merged.condition ?? "Good"), keywords: (merged.seoKeywords as string[]) ?? [],
    });
    patch.qualityScore = qs.score;
    patch.updatedAt = new Date();

    const [updated] = await db.update(listings).set(patch).where(eq(listings.id, id)).returning();
    const imgs = await db.select().from(listingImages).where(eq(listingImages.listingId, id));
    imgs.sort((a, b) => a.sortOrder - b.sortOrder);
    return NextResponse.json({ listing: { ...updated, images: imgs } });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "Failed to update listing." }, { status: 500 });
  }
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const userId = await getSessionUserId();
  if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await params;
  const row = await owned(id, userId);
  if (!row) return NextResponse.json({ error: "Not found" }, { status: 404 });
  await db.delete(listingImages).where(eq(listingImages.listingId, id));
  await db.delete(listings).where(eq(listings.id, id));
  return NextResponse.json({ ok: true });
}
