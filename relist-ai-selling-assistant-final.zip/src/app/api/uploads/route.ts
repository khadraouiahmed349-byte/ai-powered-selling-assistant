import { NextResponse } from "next/server";
import { getSessionUserId } from "@/lib/auth";
import { clientKey, rateLimit } from "@/lib/rate-limit";
import { imageDataUrl } from "@/lib/validation";

export const runtime = "nodejs";

function storageConfig() {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const bucket = process.env.SUPABASE_STORAGE_BUCKET || "listing-images";
  if (!url || !key) return null;
  return { url: url.replace(/\/$/, ""), key, bucket };
}

export async function POST(req: Request) {
  const userId = await getSessionUserId();
  if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const rl = rateLimit(clientKey(req, "upload"), 30, 60_000);
  if (!rl.ok) return NextResponse.json({ error: "Too many uploads." }, { status: 429 });
  try {
    const body = await req.json();
    const dataUrl = imageDataUrl(body.dataUrl);
    if (!dataUrl) return NextResponse.json({ error: "Invalid image. Use a JPEG, PNG or WebP data URL under 8 MB." }, { status: 400 });
    const config = storageConfig();
    if (!config) return NextResponse.json({ error: "External image storage is not configured." }, { status: 503 });
    const match = dataUrl.match(/^data:image\/(jpeg|jpg|png|webp);base64,(.+)$/i);
    if (!match) return NextResponse.json({ error: "Unsupported image format." }, { status: 400 });
    const ext = match[1].toLowerCase() === "jpg" ? "jpg" : match[1].toLowerCase();
    const mime = ext === "jpg" || ext === "jpeg" ? "image/jpeg" : `image/${ext}`;
    const bytes = Buffer.from(match[2], "base64");
    if (bytes.byteLength > 6 * 1024 * 1024) return NextResponse.json({ error: "Image exceeds 6 MB." }, { status: 413 });
    const path = `${userId}/${crypto.randomUUID()}.${ext}`;
    const upload = await fetch(`${config.url}/storage/v1/object/${encodeURIComponent(config.bucket)}/${path}`, {
      method: "POST",
      headers: { Authorization: `Bearer ${config.key}`, apikey: config.key, "Content-Type": mime, "x-upsert": "false" },
      body: bytes,
      cache: "no-store",
    });
    if (!upload.ok) {
      console.error("Supabase storage upload failed", await upload.text());
      return NextResponse.json({ error: "Image storage upload failed." }, { status: 502 });
    }
    const publicUrl = `${config.url}/storage/v1/object/public/${encodeURIComponent(config.bucket)}/${path}`;
    return NextResponse.json({ url: publicUrl });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "Upload failed." }, { status: 500 });
  }
}
