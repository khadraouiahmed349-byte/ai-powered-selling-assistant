"use client";
import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Recycle, Loader2 } from "lucide-react";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e?: React.FormEvent) => {
    e?.preventDefault();
    setError("");
    setLoading(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (!res.ok) { setError(data.error || "Login failed."); return; }
      router.push("/dashboard");
      router.refresh();
    } catch {
      setError("Something went wrong. Try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="hidden flex-col justify-between bg-slate-950 p-10 text-white lg:flex">
        <Link href="/" className="flex items-center gap-2.5">
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600"><Recycle size={20} /></span>
          <span className="text-lg font-extrabold">ReList AI</span>
        </Link>
        <div>
          <h2 className="text-4xl font-extrabold leading-tight">Welcome back, seller. Your inventory missed you.</h2>
          <div className="mt-6 space-y-3">
            {[["AI-assisted", "listing creation"], ["Photo analysis", "when AI is configured"], ["Marketplace tools", "for clearer listings"]].map(([a, b]) => (
              <div key={a} className="flex items-center gap-3 rounded-2xl border border-white/10 bg-white/5 p-4">
                <span className="h-2 w-2 rounded-full bg-emerald-400 pulse-dot" />
                <p className="text-sm"><span className="font-bold">{a}</span> <span className="text-slate-400">{b}</span></p>
              </div>
            ))}
          </div>
        </div>
        <p className="text-xs text-slate-500">AI photo analysis · price estimation · negotiation assistant</p>
      </div>

      <div className="flex items-center justify-center bg-slate-50 px-4 py-10">
        <div className="w-full max-w-md">
          <Link href="/" className="flex items-center gap-2 lg:hidden">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white"><Recycle size={18} /></span>
            <span className="font-extrabold">ReList AI</span>
          </Link>
          <h1 className="mt-6 text-3xl font-extrabold tracking-tight">Log in</h1>
          <p className="mt-1.5 text-sm text-slate-500">Pick up where you left off — your listings are waiting.</p>

          <div className="my-6 flex items-center gap-3 text-xs font-bold text-slate-400">
            <span className="h-px flex-1 bg-slate-200" /> OR <span className="h-px flex-1 bg-slate-200" />
          </div>

          <form onSubmit={(e) => submit(e)} className="space-y-3.5">
            <div>
              <label className="text-xs font-bold text-slate-700">Email</label>
              <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@shop.com"
                className="mt-1.5 w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100" />
            </div>
            <div>
              <label className="text-xs font-bold text-slate-700">Password</label>
              <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••"
                className="mt-1.5 w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100" />
            </div>
            {error && <p className="rounded-xl bg-rose-50 px-4 py-2.5 text-sm font-semibold text-rose-600 ring-1 ring-rose-100">{error}</p>}
            <button disabled={loading} className="w-full rounded-2xl bg-slate-900 px-4 py-3.5 text-sm font-bold text-white transition hover:bg-slate-700 disabled:opacity-60">
              {loading ? "Logging in…" : "Log in"}
            </button>
          </form>
          <p className="mt-5 text-center text-sm text-slate-500">
            New to ReList? <Link href="/signup" className="font-bold text-emerald-700 hover:underline">Create an account</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
