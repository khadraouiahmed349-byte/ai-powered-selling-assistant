export default function Page() {
  return <main className="min-h-screen bg-slate-50 px-5 py-12 text-slate-900"><article className="mx-auto max-w-3xl rounded-3xl border border-slate-200 bg-white p-8 shadow-sm"><h1 className="text-3xl font-black">Privacy Policy</h1><div className="mt-6 whitespace-pre-line text-sm leading-7 text-slate-600">This privacy policy is a starting template. Replace this text with the final policy reviewed for your business, jurisdiction, analytics providers, AI providers, payment processor, database and image storage.

ReList AI processes account information, listing content, uploaded images and AI requests to provide the service. Do not publish this page unchanged if your actual data practices differ.</div></article></main>;
}
