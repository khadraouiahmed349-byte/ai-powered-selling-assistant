"use client";
import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Recycle, Check } from "lucide-react";

export default function SignupPage() {
  const router = useRouter();
  const [form, setForm] = useState({ name: "", email: "", password: "", shopName: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const res = await fetch("/api/auth/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) { setError(data.error || "Signup failed."); return; }
      router.push("/dashboard/new");
      router.refresh();
    } catch {
      setError("Something went wrong. Try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="flex items-center justify-center bg-slate-50 px-4 py-10">
        <div className="w-full max-w-md">
          <Link href="/" className="flex items-center gap-2">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white"><Recycle size={18} /></span>
            <span className="font-extrabold">ReList AI</span>
          </Link>
          <h1 className="mt-6 text-3xl font-extrabold tracking-tight">Start selling smarter</h1>
          <p className="mt-1.5 text-sm text-slate-500">Free forever plan · upgrade when you scale.</p>
          <form onSubmit={submit} className="mt-6 space-y-3.5">
            <div className="grid gap-3.5 sm:grid-cols-2">
              <div>
                <label className="text-xs font-bold text-slate-700">Full name</label>
                <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Alex Seller"
                  className="mt-1.5 w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100" />
              </div>
              <div>
                <label className="text-xs font-bold text-slate-700">Shop name <span className="font-medium text-slate-400">(optional)</span></label>
                <input value={form.shopName} onChange={(e) => setForm({ ...form, shopName: e.target.value })} placeholder="Alex's Thrift Corner"
                  className="mt-1.5 w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100" />
              </div>
            </div>
            <div>
              <label className="text-xs font-bold text-slate-700">Email</label>
              <input type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="you@shop.com"
                className="mt-1.5 w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100" />
            </div>
            <div>
              <label className="text-xs font-bold text-slate-700">Password</label>
              <input type="password" required minLength={6} value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} placeholder="Min. 6 characters"
                className="mt-1.5 w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100" />
            </div>
            {error && <p className="rounded-xl bg-rose-50 px-4 py-2.5 text-sm font-semibold text-rose-600 ring-1 ring-rose-100">{error}</p>}
            <button disabled={loading} className="w-full rounded-2xl bg-emerald-600 px-4 py-3.5 text-sm font-bold text-white shadow-lg shadow-emerald-600/25 transition hover:bg-emerald-700 disabled:opacity-60">
              {loading ? "Creating account…" : "Create free account"}
            </button>
          </form>
          <p className="mt-5 text-center text-sm text-slate-500">
            Already have an account? <Link href="/login" className="font-bold text-emerald-700 hover:underline">Log in</Link>
          </p>
        </div>
      </div>
      <div className="hidden flex-col justify-center bg-gradient-to-br from-emerald-600 via-emerald-600 to-teal-700 p-12 text-white lg:flex">
        <h2 className="text-3xl font-extrabold leading-tight">Everything you need to sell second-hand like a pro.</h2>
        <ul className="mt-8 space-y-4">
          {[
            "AI photo analysis + automatic product identification",
            "AI-generated titles, descriptions & price estimation",
            "Listing quality score + marketplace optimization",
            "Negotiation assistant that closes deals for you",
            "Photo upload, listing management & copy-to-clipboard",
          ].map((t) => (
            <li key={t} className="flex items-start gap-3 rounded-2xl bg-white/10 p-4 ring-1 ring-white/20 backdrop-blur">
              <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-white text-emerald-700"><Check size={14} strokeWidth={3} /></span>
              <span className="text-sm font-semibold">{t}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
