import Link from "next/link";
import {
  Recycle, Camera, ScanSearch, PenLine, Tag, Rocket, MessagesSquare,
  Gauge, ImagePlus, LayoutGrid, ClipboardCopy, ArrowRight, Check, Star,
  Sparkles, Zap, TrendingUp, ShieldCheck, Play,
} from "lucide-react";

const KEY_FEATURES = [
  { icon: Camera, title: "AI photo analysis", desc: "Upload a photo and, when AI is configured, receive product-analysis signals and photo tips.", color: "bg-violet-50 text-violet-600 ring-violet-100" },
  { icon: ScanSearch, title: "Automatic product identification", desc: "When AI is configured, it can help identify product details from photos; verify important facts before publishing.", color: "bg-sky-50 text-sky-600 ring-sky-100" },
  { icon: PenLine, title: "AI-generated listing titles and descriptions", desc: "Draft marketplace-ready titles and descriptions that you can review and edit before publishing.", color: "bg-emerald-50 text-emerald-600 ring-emerald-100" },
  { icon: Tag, title: "Price estimation", desc: "Suggested pricing based on the information you provide; estimates are not live market quotes.", color: "bg-amber-50 text-amber-600 ring-amber-100" },
  { icon: Rocket, title: "Marketplace listing optimization", desc: "Tailored checklists for eBay, Facebook, Craigslist, noon, OpenSooq, dubizzle and more.", color: "bg-rose-50 text-rose-600 ring-rose-100" },
  { icon: MessagesSquare, title: "Negotiation assistant", desc: "Paste any buyer message and get the perfect reply — friendly, firm or professional — plus counter-offer math.", color: "bg-indigo-50 text-indigo-600 ring-indigo-100" },
  { icon: Gauge, title: "Listing quality score", desc: "A 0–100 checklist score with concrete fixes to improve listing completeness before publishing.", color: "bg-teal-50 text-teal-600 ring-teal-100" },
  { icon: ImagePlus, title: "Photo upload", desc: "Drag-and-drop multi-photo uploads with auto-optimization, cover selection and URL import.", color: "bg-orange-50 text-orange-600 ring-orange-100" },
  { icon: LayoutGrid, title: "Listing management", desc: "A clean dashboard to create, edit, track, mark sold and organize your whole second-hand inventory.", color: "bg-cyan-50 text-cyan-600 ring-cyan-100" },
  { icon: ClipboardCopy, title: "Copy-to-clipboard", desc: "One-click copy for titles, descriptions, replies and price blocks — paste straight into any marketplace.", color: "bg-lime-50 text-lime-600 ring-lime-100" },
];

const STEPS = [
  { n: "01", title: "Snap & upload", desc: "Upload photos of your used item and review the available AI analysis." },
  { n: "02", title: "AI writes & prices", desc: "Get draft titles, descriptions, keywords and a heuristic or AI-assisted price estimate." },
  { n: "03", title: "Optimize & publish", desc: "Improve the listing, copy the finished text, and publish it on your chosen marketplace." },
  { n: "04", title: "Negotiate & sell", desc: "Let the negotiation assistant turn lowballs into closed deals." },
];

const TESTIMONIALS = [
  { name: "Layla H.", role: "Thrift store owner, Amman", quote: "I list 30+ items a week. ReList writes better descriptions in 10 seconds than I did in 20 minutes. My sell-through rate doubled.", stars: 5 },
  { name: "Marcus T.", role: "eBay power seller", quote: "The quality score is addictive — I won't publish anything under 80 now. Views are up 3x and lowball messages dropped hard.", stars: 5 },
  { name: "Priya S.", role: "Weekend declutterer", quote: "Sold my entire apartment's furniture in 6 days. The price estimator was scary accurate and the negotiation replies saved me hours.", stars: 5 },
];

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* NAV */}
      <header className="sticky top-0 z-50 border-b border-slate-100 bg-white/85 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3.5 sm:px-6">
          <Link href="/" className="flex items-center gap-2.5">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white shadow-lg shadow-emerald-500/25">
              <Recycle size={18} strokeWidth={2.4} />
            </span>
            <span className="text-[17px] font-extrabold tracking-tight">ReList AI</span>
            <span className="hidden rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] font-bold text-emerald-700 ring-1 ring-emerald-200 sm:inline">BETA</span>
          </Link>
          <nav className="hidden items-center gap-7 text-sm font-semibold text-slate-600 md:flex">
            <a href="#features" className="hover:text-slate-900">Key Features</a>
            <a href="#how" className="hover:text-slate-900">How it works</a>
            <a href="#marketplaces" className="hover:text-slate-900">Marketplaces</a>
            <a href="#reviews" className="hover:text-slate-900">Reviews</a>
          </nav>
          <div className="flex items-center gap-2">
            <Link href="/login" className="rounded-xl px-4 py-2 text-sm font-bold text-slate-700 hover:bg-slate-100">Log in</Link>
            <Link href="/signup" className="rounded-xl bg-slate-900 px-4 py-2 text-sm font-bold text-white shadow-md transition hover:bg-slate-700">
              Start free
            </Link>
          </div>
        </div>
      </header>

      {/* HERO */}
      <section className="relative overflow-hidden">
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(60rem_30rem_at_50%_-10%,#d1fae5_0%,transparent_60%)]" />
        <div className="relative mx-auto grid max-w-7xl items-center gap-10 px-4 pb-16 pt-14 sm:px-6 lg:grid-cols-2 lg:pt-20">
          <div className="animate-fadeUp">
            <p className="inline-flex items-center gap-2 rounded-full bg-emerald-50 px-3.5 py-1.5 text-xs font-bold text-emerald-700 ring-1 ring-emerald-200">
              <Sparkles size={13} /> The AI assistant for second-hand sellers
            </p>
            <h1 className="mt-5 text-4xl font-extrabold leading-[1.05] tracking-tight text-slate-950 sm:text-5xl lg:text-[3.6rem]">
              Create better used-item listings <span className="bg-gradient-to-r from-emerald-600 to-teal-500 bg-clip-text text-transparent">with AI assistance</span>
            </h1>
            <p className="mt-5 max-w-lg text-base leading-relaxed text-slate-600 sm:text-lg">
              Built for individuals, small businesses, and marketplace sellers. Snap a photo — ReList identifies the product, writes the listing, estimates the price, and even handles hagglers.
            </p>
            <div className="mt-7 flex flex-wrap gap-3">
              <Link href="/signup" className="inline-flex items-center gap-2 rounded-2xl bg-emerald-600 px-6 py-3.5 text-sm font-bold text-white shadow-xl shadow-emerald-600/25 transition hover:bg-emerald-700 active:scale-95">
                Create your first listing <ArrowRight size={16} />
              </Link>
              <Link href="/login" className="inline-flex items-center gap-2 rounded-2xl bg-white px-6 py-3.5 text-sm font-bold text-slate-800 ring-1 ring-slate-200 transition hover:bg-slate-50 active:scale-95">
                <Play size={15} /> Try live demo
              </Link>
            </div>
            <div className="mt-7 flex flex-wrap items-center gap-x-6 gap-y-2 text-sm text-slate-600">
              <span className="flex items-center gap-1.5"><Check size={15} className="text-emerald-600" strokeWidth={3} /> Free to start</span>
              <span className="flex items-center gap-1.5"><Check size={15} className="text-emerald-600" strokeWidth={3} /> No credit card</span>
              <span className="flex items-center gap-1.5"><Check size={15} className="text-emerald-600" strokeWidth={3} /> Works with any marketplace</span>
            </div>
            <div className="mt-6 flex items-center gap-3">
              <div className="flex -space-x-2">
                {["from-violet-500 to-purple-600", "from-amber-500 to-orange-600", "from-sky-500 to-blue-600", "from-rose-500 to-pink-600"].map((g, i) => (
                  <span key={i} className={`grid h-8 w-8 place-items-center rounded-full bg-gradient-to-br ${g} text-xs font-bold text-white ring-2 ring-white`}>
                    {["L", "M", "P", "S"][i]}
                  </span>
                ))}
              </div>
              <p className="text-xs text-slate-500">Create, optimize, and manage your listings in one place</p>
            </div>
          </div>

          {/* hero mock card */}
          <div className="relative animate-fadeUp">
            <div className="absolute -inset-4 rounded-[2rem] bg-gradient-to-br from-emerald-200/60 via-teal-100/40 to-transparent blur-2xl" />
            <div className="relative overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-2xl">
              <div className="flex items-center gap-2 border-b border-slate-100 px-4 py-3">
                <span className="h-2.5 w-2.5 rounded-full bg-rose-400" /><span className="h-2.5 w-2.5 rounded-full bg-amber-400" /><span className="h-2.5 w-2.5 rounded-full bg-emerald-400" />
                <span className="ml-2 text-xs font-semibold text-slate-400">app.relist.ai — AI Listing Studio</span>
              </div>
              <div className="grid sm:grid-cols-2">
                <img src="https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=700&q=80" alt="AI analyzed iPhone" className="h-52 w-full object-cover sm:h-full" />
                <div className="p-5">
                  <p className="inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-2.5 py-1 text-[11px] font-bold text-emerald-700">
                    <Zap size={11} /> AI analysis example
                  </p>
                  <h3 className="mt-2 text-[15px] font-bold leading-snug">Apple iPhone 13 128GB Midnight — Unlocked, Battery 89%</h3>
                  <div className="mt-2 flex items-center gap-2">
                    <span className="text-xl font-extrabold">$429</span>
                    <span className="rounded-md bg-slate-100 px-2 py-0.5 text-[11px] font-bold text-slate-600">Est. $377–$481</span>
                  </div>
                  <div className="mt-3">
                    <div className="flex items-center justify-between text-[11px] font-bold"><span>Listing quality score</span><span className="text-emerald-600">92 · Excellent</span></div>
                    <div className="mt-1.5 h-2 overflow-hidden rounded-full bg-slate-100">
                      <div className="h-full w-[92%] rounded-full bg-gradient-to-r from-emerald-500 to-teal-400" />
                    </div>
                  </div>
                  <div className="mt-3 flex gap-2">
                    <span className="flex-1 rounded-lg bg-slate-900 py-2 text-center text-xs font-bold text-white">⧉ Copy listing</span>
                    <span className="flex-1 rounded-lg bg-emerald-600 py-2 text-center text-xs font-bold text-white">Publish ✓</span>
                  </div>
                </div>
              </div>
              <div className="border-t border-slate-100 bg-slate-50/70 px-5 py-3">
                <p className="text-xs text-slate-600"><span className="font-bold text-slate-800">💬 Buyer:</span> “Would you take $380?” <span className="ml-1 rounded-md bg-indigo-50 px-2 py-0.5 font-bold text-indigo-700">AI reply ready →</span></p>
              </div>
            </div>
            <div className="absolute -bottom-5 -left-4 hidden items-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-3 shadow-xl sm:flex" style={{ animation: "floaty 4s ease-in-out infinite" }}>
              <span className="grid h-9 w-9 place-items-center rounded-xl bg-emerald-50 text-emerald-600"><TrendingUp size={18} /></span>
              <span><span className="block text-sm font-extrabold">AI optimization</span><span className="block text-[11px] text-slate-500">example result</span></span>
            </div>
            <div className="absolute -right-3 -top-5 hidden items-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-3 shadow-xl sm:flex" style={{ animation: "floaty 5s ease-in-out infinite" }}>
              <span className="grid h-9 w-9 place-items-center rounded-xl bg-amber-50 text-amber-600"><ShieldCheck size={18} /></span>
              <span><span className="block text-sm font-extrabold">Sold in 2 days</span><span className="block text-[11px] text-slate-500">PS5 · $399 · via AI reply</span></span>
            </div>
          </div>
        </div>
      </section>

      {/* LOGOS STRIP */}
      <section id="marketplaces" className="border-y border-slate-100 bg-slate-50/60 py-8">
        <p className="text-center text-xs font-bold uppercase tracking-[0.16em] text-slate-400">Optimized for every marketplace you sell on</p>
        <div className="mx-auto mt-4 flex max-w-5xl flex-wrap items-center justify-center gap-2.5 px-4">
          {["eBay", "Facebook Marketplace", "Craigslist", "Amazon Renewed", "noon", "OpenSooq", "dubizzle", "Depop", "Vinted", "OfferUp"].map((m) => (
            <span key={m} className="rounded-full bg-white px-4 py-2 text-sm font-bold text-slate-700 ring-1 ring-slate-200 shadow-sm">{m}</span>
          ))}
        </div>
      </section>

      {/* KEY FEATURES */}
      <section id="features" className="mx-auto max-w-7xl px-4 py-20 sm:px-6">
        <div className="mx-auto max-w-2xl text-center">
          <p className="text-xs font-bold uppercase tracking-[0.16em] text-emerald-600">Everything in one studio</p>
          <h2 className="mt-2 text-3xl font-extrabold tracking-tight sm:text-4xl">Key Features</h2>
          <p className="mt-3 text-slate-600">AI photo analysis, automatic product identification, AI-generated listing titles and descriptions, price estimation, marketplace listing optimization, negotiation assistant, listing quality score, photo upload, listing management, and copy-to-clipboard.</p>
        </div>
        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {KEY_FEATURES.map((f, i) => (
            <div key={f.title} className={`group rounded-2xl border border-slate-200/80 bg-white p-5 transition-all hover:-translate-y-1 hover:shadow-[0_16px_40px_rgba(16,24,40,0.10)] ${i === KEY_FEATURES.length - 1 ? "sm:col-span-2 lg:col-span-1" : ""}`}>
              <span className={`inline-grid h-11 w-11 place-items-center rounded-xl ring-1 ${f.color}`}>
                <f.icon size={21} strokeWidth={2.2} />
              </span>
              <h3 className="mt-3 text-[15px] font-bold">{f.title}</h3>
              <p className="mt-1.5 text-sm leading-relaxed text-slate-500">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* HOW */}
      <section id="how" className="bg-slate-950 py-20 text-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="mx-auto max-w-2xl text-center">
            <p className="text-xs font-bold uppercase tracking-[0.16em] text-emerald-400">From photo to sold</p>
            <h2 className="mt-2 text-3xl font-extrabold tracking-tight sm:text-4xl">How it works</h2>
          </div>
          <div className="mt-10 grid gap-4 md:grid-cols-4">
            {STEPS.map((s) => (
              <div key={s.n} className="rounded-2xl border border-white/10 bg-white/5 p-5 backdrop-blur">
                <p className="bg-gradient-to-r from-emerald-400 to-teal-300 bg-clip-text text-3xl font-extrabold text-transparent">{s.n}</p>
                <h3 className="mt-2 font-bold">{s.title}</h3>
                <p className="mt-1 text-sm text-slate-400">{s.desc}</p>
              </div>
            ))}
          </div>
          <div className="mt-10 text-center">
            <Link href="/signup" className="inline-flex items-center gap-2 rounded-2xl bg-emerald-500 px-7 py-3.5 text-sm font-bold text-white shadow-xl shadow-emerald-500/25 transition hover:bg-emerald-400">
              Start selling smarter <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>

      {/* REVIEWS */}
      <section id="reviews" className="mx-auto max-w-7xl px-4 py-20 sm:px-6">
        <div className="mx-auto max-w-2xl text-center">
          <p className="text-xs font-bold uppercase tracking-[0.16em] text-emerald-600">Loved by sellers</p>
          <h2 className="mt-2 text-3xl font-extrabold tracking-tight sm:text-4xl">Individuals, shops & marketplace pros</h2>
        </div>
        <div className="mt-10 grid gap-4 md:grid-cols-3">
          {TESTIMONIALS.map((t) => (
            <figure key={t.name} className="rounded-2xl border border-slate-200/80 bg-white p-6 shadow-sm">
              <div className="flex gap-0.5 text-amber-400">
                {Array.from({ length: t.stars }).map((_, i) => <Star key={i} size={15} fill="currentColor" />)}
              </div>
              <blockquote className="mt-3 text-[15px] leading-relaxed text-slate-700">“{t.quote}”</blockquote>
              <figcaption className="mt-4 border-t border-slate-100 pt-4">
                <p className="text-sm font-bold">{t.name}</p>
                <p className="text-xs text-slate-500">{t.role}</p>
              </figcaption>
            </figure>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-7xl px-4 pb-20 sm:px-6">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-600 via-emerald-600 to-teal-600 px-6 py-14 text-center text-white shadow-2xl shadow-emerald-600/25 sm:px-12">
          <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(40rem_20rem_at_50%_0%,rgba(255,255,255,0.2),transparent)]" />
          <h2 className="relative text-3xl font-extrabold tracking-tight sm:text-4xl">Your next listing can start from a photo.</h2>
          <p className="relative mx-auto mt-3 max-w-xl text-emerald-50">Use AI assistance to draft clearer listings, estimate prices, and prepare marketplace copy.</p>
          <div className="relative mt-7 flex flex-wrap justify-center gap-3">
            <Link href="/signup" className="rounded-2xl bg-white px-7 py-3.5 text-sm font-bold text-emerald-700 shadow-lg transition hover:bg-emerald-50">Get started free</Link>
            <Link href="/login" className="rounded-2xl bg-emerald-700/60 px-7 py-3.5 text-sm font-bold text-white ring-1 ring-white/30 transition hover:bg-emerald-700">Log in</Link>
          </div>
          <p className="relative mt-4 text-xs text-emerald-100">Create an account to try the app</p>
        </div>
      </section>

      <footer className="border-t border-slate-200 bg-slate-50 py-10">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-4 sm:flex-row sm:px-6">
          <p className="flex items-center gap-2 text-sm font-bold"><Recycle size={16} className="text-emerald-600" /> ReList AI — Used Product Selling Assistant</p>
          <p className="text-xs text-slate-500">Made for the circular economy · Sell pre-loved, buy happy ♻️</p>
        </div>
      </footer>
    </div>
  );
}
