import Link from "next/link";
import { Check, Sparkles, ArrowLeft } from "lucide-react";

const features = ["AI product photo analysis", "AI listing title + description", "AI price estimation", "Marketplace optimizer", "Negotiation reply assistant"];

export default function PricingPage() {
  return <main className="min-h-screen bg-slate-50 px-5 py-12 text-slate-900"><div className="mx-auto max-w-5xl">
    <Link href="/" className="inline-flex items-center gap-2 text-sm font-bold text-slate-500"><ArrowLeft size={15}/> Back</Link>
    <div className="mx-auto max-w-2xl py-12 text-center"><div className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-emerald-100 text-emerald-700"><Sparkles/></div><h1 className="mt-4 text-4xl font-black tracking-tight">Simple pricing</h1><p className="mt-3 text-slate-500">Start free. Upgrade when you need more AI listings.</p></div>
    <div className="grid gap-6 md:grid-cols-2">
      <section className="rounded-3xl border border-slate-200 bg-white p-7 shadow-sm"><h2 className="text-xl font-black">Free</h2><p className="mt-2 text-4xl font-black">$0<span className="text-base font-semibold text-slate-400"> / month</span></p><p className="mt-2 text-sm text-slate-500">10 AI actions per month.</p><ul className="mt-6 space-y-3">{features.map(f=><li key={f} className="flex gap-2 text-sm"><Check size={17} className="text-emerald-600"/>{f}</li>)}</ul><Link href="/signup" className="mt-7 block rounded-xl bg-slate-900 px-5 py-3 text-center text-sm font-bold text-white">Create free account</Link></section>
      <section className="rounded-3xl border-2 border-emerald-500 bg-white p-7 shadow-lg"><div className="text-xs font-black uppercase tracking-wider text-emerald-700">Recommended</div><h2 className="mt-2 text-xl font-black">Pro</h2><p className="mt-2 text-4xl font-black">$9<span className="text-base font-semibold text-slate-400"> / month</span></p><p className="mt-2 text-sm text-slate-500">200 AI actions per month.</p><ul className="mt-6 space-y-3">{features.map(f=><li key={f} className="flex gap-2 text-sm"><Check size={17} className="text-emerald-600"/>{f}</li>)}</ul><a href="/api/billing/checkout?plan=pro" className="mt-7 block rounded-xl bg-emerald-600 px-5 py-3 text-center text-sm font-bold text-white">Upgrade to Pro</a></section>
    </div>
  </div></main>;
}
