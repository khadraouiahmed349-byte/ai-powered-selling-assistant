import { pgTable, text, timestamp, uuid, integer, jsonb, boolean } from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  shopName: text("shop_name"),
  avatarColor: text("avatar_color").notNull().default("emerald"),
  plan: text("plan").notNull().default("free"), // free | pro
  subscriptionStatus: text("subscription_status").notNull().default("inactive"),
  lemonSubscriptionId: text("lemon_subscription_id"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const aiUsage = pgTable("ai_usage", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  month: text("month").notNull(),
  count: integer("count").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const listings = pgTable("listings", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  description: text("description").notNull().default(""),
  category: text("category").notNull().default("Other"),
  brand: text("brand").notNull().default(""),
  condition: text("condition").notNull().default("Good"),
  price: integer("price").notNull().default(0), // cents
  originalPrice: integer("original_price"), // cents
  estimatedLow: integer("estimated_low"),
  estimatedHigh: integer("estimated_high"),
  suggestedPrice: integer("suggested_price"),
  status: text("status").notNull().default("draft"), // draft | active | sold | archived
  qualityScore: integer("quality_score").notNull().default(0),
  marketplaceTargets: jsonb("marketplace_targets").$type<string[]>().notNull().default([]),
  aiAnalysis: jsonb("ai_analysis").$type<Record<string, unknown>>().default({}),
  seoKeywords: jsonb("seo_keywords").$type<string[]>().notNull().default([]),
  views: integer("views").notNull().default(0),
  inquiries: integer("inquiries").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export const listingImages = pgTable("listing_images", {
  id: uuid("id").defaultRandom().primaryKey(),
  listingId: uuid("listing_id")
    .notNull()
    .references(() => listings.id, { onDelete: "cascade" }),
  url: text("url").notNull(),
  isPrimary: boolean("is_primary").notNull().default(false),
  sortOrder: integer("sort_order").notNull().default(0),
  aiTags: jsonb("ai_tags").$type<string[]>().notNull().default([]),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const negotiations = pgTable("negotiations", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  listingId: uuid("listing_id").references(() => listings.id, { onDelete: "set null" }),
  listingTitle: text("listing_title").notNull().default(""),
  buyerName: text("buyer_name").notNull(),
  buyerMessage: text("buyer_message").notNull(),
  offerPrice: integer("offer_price"), // cents, nullable
  askingPrice: integer("asking_price").notNull().default(0),
  status: text("status").notNull().default("new"), // new | countered | accepted | declined
  suggestedReply: text("suggested_reply").notNull().default(""),
  tone: text("tone").notNull().default("friendly"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type AiUsage = typeof aiUsage.$inferSelect;
export type Listing = typeof listings.$inferSelect;
export type ListingImage = typeof listingImages.$inferSelect;
export type Negotiation = typeof negotiations.$inferSelect;
