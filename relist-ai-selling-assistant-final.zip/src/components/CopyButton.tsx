"use client";
import { useState } from "react";
import { Check, Copy } from "lucide-react";
import { copyToClipboard } from "@/lib/utils";
import { cn } from "@/lib/utils";

export default function CopyButton({ text, label = "Copy", className, small }: { text: string; label?: string; className?: string; small?: boolean }) {
  const [ok, setOk] = useState(false);
  return (
    <button
      onClick={async () => {
        const done = await copyToClipboard(text);
        if (done) { setOk(true); setTimeout(() => setOk(false), 1600); }
      }}
      className={cn(
        "inline-flex items-center gap-1.5 rounded-lg font-semibold transition-all active:scale-95",
        small ? "px-2.5 py-1.5 text-xs" : "px-3.5 py-2 text-sm",
        ok ? "bg-emerald-600 text-white" : "bg-slate-900 text-white hover:bg-slate-700",
        className
      )}
    >
      {ok ? <Check size={small ? 13 : 15} /> : <Copy size={small ? 13 : 15} />}
      {ok ? "Copied!" : label}
    </button>
  );
}
