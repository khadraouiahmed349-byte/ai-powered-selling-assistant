"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useState } from "react";
import {
  LayoutDashboard, Package, PlusCircle, Calculator, MessagesSquare,
  Rocket, LogOut, Menu, X, Recycle, Sparkles,
} from "lucide-react";
import { cn } from "@/lib/utils";

const NAV = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard, exact: true },
  { href: "/dashboard/listings", label: "My Listings", icon: Package },
  { href: "/dashboard/new", label: "Create Listing", icon: PlusCircle, highlight: true },
  { href: "/dashboard/estimator", label: "Price Estimator", icon: Calculator },
  { href: "/dashboard/negotiations", label: "Negotiations", icon: MessagesSquare },
  { href: "/dashboard/optimizer", label: "Marketplace Optimizer", icon: Rocket },
];

export default function Sidebar({ user }: { user: { name: string; email: string; shopName?: string | null; avatarColor?: string } }) {
  const pathname = usePathname();
  const router = useRouter();
  const [open, setOpen] = useState(false);

  const logout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/");
    router.refresh();
  };

  const colorMap: Record<string, string> = {
    emerald: "from-emerald-500 to-teal-600",
    violet: "from-violet-500 to-purple-600",
    amber: "from-amber-500 to-orange-600",
    sky: "from-sky-500 to-blue-600",
    rose: "from-rose-500 to-pink-600",
  };
  const avatar = colorMap[user.avatarColor || "emerald"] || colorMap.emerald;

  const navContent = (
    <div className="flex h-full flex-col">
      <Link href="/dashboard" className="flex items-center gap-2.5 px-2 py-1" onClick={() => setOpen(false)}>
        <span className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white shadow-lg shadow-emerald-500/25">
          <Recycle size={20} strokeWidth={2.4} />
        </span>
        <span>
          <span className="block text-[15px] font-extrabold tracking-tight text-slate-900">ReList AI</span>
          <span className="block text-[11px] font-medium text-slate-500">Sell pre-loved, faster</span>
        </span>
      </Link>

      <div className="mt-5 rounded-xl border border-emerald-100 bg-gradient-to-br from-emerald-50 to-teal-50 p-3">
        <p className="flex items-center gap-1.5 text-xs font-bold text-emerald-800"><Sparkles size={13} /> AI credits</p>
        <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-emerald-100">
          <div className="h-full w-3/4 rounded-full bg-gradient-to-r from-emerald-500 to-teal-500" />
        </div>
        <p className="mt-1.5 text-[11px] text-emerald-700">Unlimited on Pro trial · 12 days left</p>
      </div>

      <nav className="mt-4 flex-1 space-y-1 overflow-y-auto">
        {NAV.map((n) => {
          const active = n.exact ? pathname === n.href : pathname.startsWith(n.href);
          const Icon = n.icon;
          return (
            <Link
              key={n.href}
              href={n.href}
              onClick={() => setOpen(false)}
              className={cn(
                "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold transition-all",
                active
                  ? "bg-slate-900 text-white shadow-md"
                  : n.highlight
                    ? "bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200 hover:bg-emerald-100"
                    : "text-slate-600 hover:bg-slate-100 hover:text-slate-900"
              )}
            >
              <Icon size={18} strokeWidth={2.2} />
              {n.label}
              {n.highlight && !active && (
                <span className="ml-auto rounded-full bg-emerald-600 px-2 py-0.5 text-[10px] font-bold text-white">AI</span>
              )}
            </Link>
          );
        })}
      </nav>

      <div className="mt-4 rounded-xl border border-slate-200 bg-slate-50 p-3">
        <div className="flex items-center gap-2.5">
          <span className={cn("grid h-9 w-9 shrink-0 place-items-center rounded-full bg-gradient-to-br text-sm font-extrabold text-white", avatar)}>
            {user.name.charAt(0).toUpperCase()}
          </span>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-bold text-slate-900">{user.shopName || user.name}</p>
            <p className="truncate text-xs text-slate-500">{user.email}</p>
          </div>
        </div>
        <button onClick={logout} className="mt-2.5 flex w-full items-center justify-center gap-2 rounded-lg bg-white px-3 py-2 text-xs font-bold text-slate-600 ring-1 ring-slate-200 transition hover:bg-slate-100 hover:text-slate-900">
          <LogOut size={14} /> Sign out
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* mobile topbar */}
      <div className="sticky top-0 z-40 flex items-center justify-between border-b border-slate-200 bg-white/90 px-4 py-3 backdrop-blur lg:hidden">
        <Link href="/dashboard" className="flex items-center gap-2">
          <span className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-to-br from-emerald-500 to-teal-600 text-white">
            <Recycle size={16} />
          </span>
          <span className="text-sm font-extrabold">ReList AI</span>
        </Link>
        <button onClick={() => setOpen(true)} className="rounded-lg p-2 text-slate-600 hover:bg-slate-100" aria-label="Open menu">
          <Menu size={20} />
        </button>
      </div>

      {/* desktop sidebar */}
      <aside className="sticky top-0 hidden h-screen w-72 shrink-0 overflow-y-auto border-r border-slate-200 bg-white p-4 lg:block">
        {navContent}
      </aside>

      {/* mobile drawer */}
      {open && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-slate-900/50" onClick={() => setOpen(false)} />
          <aside className="absolute left-0 top-0 h-full w-80 max-w-[85vw] overflow-y-auto bg-white p-4 shadow-2xl animate-fadeUp">
            <div className="mb-3 flex justify-end">
              <button onClick={() => setOpen(false)} className="rounded-lg p-2 text-slate-500 hover:bg-slate-100" aria-label="Close menu">
                <X size={20} />
              </button>
            </div>
            {navContent}
          </aside>
        </div>
      )}
    </>
  );
}
