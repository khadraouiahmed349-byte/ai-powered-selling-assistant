"use client";
import Link from "next/link";
import { Eye, MessageCircle, MapPin } from "lucide-react";
import { formatMoney, STATUS_META, timeAgo, cn } from "@/lib/utils";
import { scoreColor } from "@/lib/utils";

export type CardListing = {
  id: string; title: string; category: string; condition: string;
  price: number; status: string; qualityScore: number;
  views: number; inquiries: number; updatedAt: string | Date;
  images: Array<{ url: string }>;
  marketplaceTargets?: string[];
};

export default function ListingCard({ listing, onDelete }: { listing: CardListing; onDelete?: (id: string) => void }) {
  const st = STATUS_META[listing.status] ?? STATUS_META.draft;
  const sc = scoreColor(listing.qualityScore);
  const img = listing.images?.[0]?.url;
  return (
    <div className="group overflow-hidden rounded-2xl border border-slate-200/80 bg-white transition-all hover:-translate-y-0.5 hover:shadow-[0_16px_40px_rgba(16,24,40,0.12)]">
      <Link href={`/dashboard/listings/${listing.id}`} className="relative block aspect-[16/10] overflow-hidden bg-slate-100">
        {img ? (
          <img src={img} alt={listing.title} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" loading="lazy" />
        ) : (
          <span className="grid h-full w-full place-items-center text-4xl">📦</span>
        )}
        <span className={cn("absolute left-3 top-3 inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-bold ring-1", st.classes)}>
          <span className={cn("h-1.5 w-1.5 rounded-full", st.dot)} />{st.label}
        </span>
        <span className="absolute right-3 top-3 rounded-full bg-slate-900/85 px-2.5 py-1 text-[11px] font-bold text-white backdrop-blur">
          Score {listing.qualityScore}
        </span>
      </Link>
      <div className="p-4">
        <div className="flex items-center gap-2 text-[11px] font-semibold text-slate-500">
          <span className="rounded-md bg-slate-100 px-2 py-0.5">{listing.category}</span>
          <span className="rounded-md bg-slate-100 px-2 py-0.5">{listing.condition}</span>
          <span className="ml-auto">{timeAgo(listing.updatedAt)}</span>
        </div>
        <Link href={`/dashboard/listings/${listing.id}`}>
          <h3 className="mt-2 line-clamp-2 min-h-[2.6rem] text-[15px] font-bold leading-snug text-slate-900 hover:text-emerald-700">{listing.title}</h3>
        </Link>
        <div className="mt-1 flex items-center justify-between">
          <p className="text-lg font-extrabold text-slate-900">{formatMoney(listing.price)}</p>
          <span className={cn("text-xs font-bold", sc.text)}>{sc.label}</span>
        </div>
        <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-slate-100">
          <div className={cn("h-full rounded-full transition-all", sc.bar)} style={{ width: `${listing.qualityScore}%` }} />
        </div>
        <div className="mt-3 flex items-center justify-between border-t border-slate-100 pt-3 text-xs text-slate-500">
          <span className="flex items-center gap-3">
            <span className="flex items-center gap-1"><Eye size={14} /> {listing.views}</span>
            <span className="flex items-center gap-1"><MessageCircle size={14} /> {listing.inquiries}</span>
            {(listing.marketplaceTargets?.length ?? 0) > 0 && (
              <span className="flex items-center gap-1"><MapPin size={14} /> {listing.marketplaceTargets!.length}</span>
            )}
          </span>
          {onDelete && (
            <button
              onClick={() => onDelete(listing.id)}
              className="rounded-lg px-2 py-1 font-bold text-rose-500 hover:bg-rose-50"
            >
              Delete
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
