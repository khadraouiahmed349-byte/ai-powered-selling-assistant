"use client";
import { useRef, useState } from "react";
import { ImagePlus, X, Star, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

export default function PhotoUploader({ images, onChange, max = 8 }: { images: string[]; onChange: (imgs: string[]) => void; max?: number }) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragOver, setDragOver] = useState(false);
  const [loading, setLoading] = useState(false);
  const [urlInput, setUrlInput] = useState("");
  const [error, setError] = useState("");

  const processFiles = async (files: FileList | File[]) => {
    const arr = Array.from(files).filter((f) => f.type.startsWith("image/")).slice(0, max - images.length);
    if (!arr.length) return;
    setError("");
    setLoading(true);
    try {
      const results: string[] = [];
      for (const f of arr) {
        const dataUrl: string = await new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => {
            const img = new Image();
            img.onload = () => {
              // downscale to max 1200px to keep DB light
              const canvas = document.createElement("canvas");
              const scale = Math.min(1, 1200 / Math.max(img.width, img.height));
              canvas.width = Math.round(img.width * scale);
              canvas.height = Math.round(img.height * scale);
              const ctx = canvas.getContext("2d");
              if (!ctx) { resolve(reader.result as string); return; }
              ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
              resolve(canvas.toDataURL("image/jpeg", 0.82));
            };
            img.onerror = () => resolve(reader.result as string);
            img.src = reader.result as string;
          };
          reader.onerror = reject;
          reader.readAsDataURL(f);
        });
        results.push(dataUrl);
      }
      const uploaded: string[] = [];
      for (const dataUrl of results) {
        const response = await fetch("/api/uploads", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ dataUrl }) });
        const data = await response.json().catch(() => ({})) as { url?: string; error?: string };
        if (!response.ok || !data.url) {
          throw new Error(data.error || "Image upload failed. Configure external image storage and try again.");
        }
        uploaded.push(data.url);
      }
      onChange([...images, ...uploaded]);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Image upload failed. Try again.");
    } finally {
      setLoading(false);
    }
  };

  const addUrl = () => {
    if (!urlInput.trim() || images.length >= max) return;
    onChange([...images, urlInput.trim()]);
    setUrlInput("");
  };

  return (
    <div>
      <div
        onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
        onDragLeave={() => setDragOver(false)}
        onDrop={(e) => { e.preventDefault(); setDragOver(false); processFiles(e.dataTransfer.files); }}
        onClick={() => inputRef.current?.click()}
        className={cn(
          "flex cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-dashed px-6 py-8 text-center transition-all",
          dragOver ? "border-emerald-500 bg-emerald-50" : "border-slate-300 bg-slate-50 hover:border-emerald-400 hover:bg-emerald-50/50"
        )}
      >
        <input ref={inputRef} type="file" accept="image/*" multiple className="hidden"
          onChange={(e) => { if (e.target.files) processFiles(e.target.files); e.target.value = ""; }} />
        {loading ? (
          <Loader2 className="animate-spin text-emerald-600" size={28} />
        ) : (
          <span className="grid h-12 w-12 place-items-center rounded-2xl bg-emerald-600 text-white shadow-lg shadow-emerald-600/25">
            <ImagePlus size={22} />
          </span>
        )}
        <p className="mt-3 text-sm font-bold text-slate-900">Drop photos here or click to upload</p>
        <p className="mt-1 text-xs text-slate-500">JPG/PNG · auto-optimized · up to {max} photos · first = cover</p>
      </div>

      <div className="mt-2 flex gap-2">
        <input
          value={urlInput}
          onChange={(e) => setUrlInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), addUrl())}
          placeholder="…or paste an image URL and press Enter"
          className="w-full rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-sm outline-none placeholder:text-slate-400 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100"
        />
        <button onClick={addUrl} className="shrink-0 rounded-xl bg-slate-900 px-4 text-sm font-bold text-white hover:bg-slate-700">Add</button>
      </div>

      {error && <p className="mt-2 rounded-lg bg-rose-50 px-3 py-2 text-xs font-medium text-rose-700" role="alert">{error}</p>}

      {images.length > 0 && (
        <div className="mt-3 grid grid-cols-3 gap-2 sm:grid-cols-4">
          {images.map((src, i) => (
            <div key={i} className={cn("group relative aspect-square overflow-hidden rounded-xl bg-slate-100 ring-2", i === 0 ? "ring-emerald-500" : "ring-transparent")}>
              <img src={src} alt={`upload ${i + 1}`} className="h-full w-full object-cover" />
              {i === 0 && (
                <span className="absolute left-1.5 top-1.5 flex items-center gap-1 rounded-md bg-emerald-600 px-1.5 py-0.5 text-[10px] font-bold text-white">
                  <Star size={10} /> Cover
                </span>
              )}
              <div className="absolute inset-x-1 bottom-1 flex gap-1 opacity-0 transition group-hover:opacity-100">
                {i !== 0 && (
                  <button onClick={(e) => { e.stopPropagation(); const c = [...images]; const [x] = c.splice(i, 1); c.unshift(x); onChange(c); }}
                    className="flex-1 rounded-md bg-white/95 py-1 text-[10px] font-bold text-slate-700">Set cover</button>
                )}
              </div>
              <button
                onClick={(e) => { e.stopPropagation(); onChange(images.filter((_, j) => j !== i)); }}
                className="absolute right-1.5 top-1.5 grid h-6 w-6 place-items-center rounded-full bg-slate-900/80 text-white hover:bg-rose-600"
                aria-label="Remove photo"
              >
                <X size={13} />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
