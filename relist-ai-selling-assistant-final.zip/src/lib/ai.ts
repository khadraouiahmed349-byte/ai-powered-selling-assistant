// Heuristic on-device "AI" engine — deterministic, fast, no external keys needed.
// Produces realistic product identification, titles, descriptions, pricing & advice.

export type Condition = "Like New" | "Excellent" | "Good" | "Fair" | "For Parts";

export function heuristicAI() { return true; }

const CONDITION_MULT: Record<Condition, number> = {
  "Like New": 0.82,
  Excellent: 0.72,
  Good: 0.6,
  Fair: 0.45,
  "For Parts": 0.22,
};

const CATEGORY_BASELINE: Record<string, { low: number; high: number; keywords: string[] }> = {
  Phones: { low: 12000, high: 95000, keywords: ["unlocked", "battery health", "original box", "no scratches", "face id"] },
  "Laptops & Computers": { low: 25000, high: 180000, keywords: ["ssd", "ram", "charger included", "fresh thermal paste", "no dead pixels"] },
  Audio: { low: 3000, high: 45000, keywords: ["noise cancelling", "bluetooth 5.3", "original case", "low hours"] },
  Cameras: { low: 15000, high: 220000, keywords: ["shutter count", "sensor clean", "kit lens", "battery x2"] },
  Gaming: { low: 15000, high: 60000, keywords: ["ssd expanded", "2 controllers", "dust free", "hdmi included"] },
  "Home & Furniture": { low: 5000, high: 120000, keywords: ["solid wood", "pet-free home", "no stains", "disassembly available"] },
  Fashion: { low: 1500, high: 60000, keywords: ["authentic", "worn twice", "no defects", "dust bag"] },
  "Bikes & Scooters": { low: 12000, high: 150000, keywords: ["tuned", "new tires", "low mileage", "lock included"] },
  Appliances: { low: 8000, high: 90000, keywords: ["energy star", "descaled", "all attachments", "manual included"] },
  Sports: { low: 4000, high: 80000, keywords: ["barely used", "all sizes parts", "garage kept"] },
  "Toys & Kids": { low: 1000, high: 35000, keywords: ["complete set", "sanitized", "smoke-free", "batteries included"] },
  "Cars & Parts": { low: 20000, high: 900000, keywords: ["service history", "oem parts", "no accidents"] },
  Other: { low: 2000, high: 50000, keywords: ["tested", "working perfectly", "from smoke-free home"] },
};

const PRODUCT_HINTS: Array<{ match: RegExp; product: string; brand: string; category: string; title: string; specs: string[] }> = [
  { match: /iphone|apple.*phone/i, product: "Apple iPhone", brand: "Apple", category: "Phones", title: "Apple iPhone 13 128GB Midnight — Unlocked, Battery 89%", specs: ["128GB storage", "Unlocked for all carriers", "Battery health 89%", "Original box + cable"] },
  { match: /samsung|galaxy/i, product: "Samsung Galaxy", brand: "Samsung", category: "Phones", title: "Samsung Galaxy S22 5G 128GB — Excellent, Unlocked", specs: ["128GB / 8GB RAM", "120Hz AMOLED, no burn-in", "Unlocked", "Case + screen protector since day one"] },
  { match: /macbook|mac book/i, product: "Apple MacBook", brand: "Apple", category: "Laptops & Computers", title: "MacBook Air M1 2020 8/256 — Battery 91%, Space Gray", specs: ["Apple M1 chip", "8GB unified memory", "256GB SSD", "Battery cycle 142, health 91%"] },
  { match: /thinkpad|dell xps|lenovo|hp.*laptop|asus/i, product: "Laptop", brand: "Lenovo", category: "Laptops & Computers", title: "ThinkPad-grade Business Laptop i7 16GB/512GB SSD — Fresh Windows", specs: ["Intel i7 11th gen", "16GB RAM / 512GB NVMe", "Backlit keyboard", "Original 65W charger"] },
  { match: /sony.*head|wh-1000|airpods|bose|headphone|earbud/i, product: "Wireless Headphones", brand: "Sony", category: "Audio", title: "Sony WH-1000XM4 Noise Cancelling Headphones — Like New", specs: ["Industry-leading ANC", "30h battery", "Original case + cables", "Low hours, adult owned"] },
  { match: /canon|nikon|sony.*(a7|alpha)|camera|lens|gopro/i, product: "Mirrorless Camera", brand: "Sony", category: "Cameras", title: "Sony A6400 Mirrorless + 16-50mm Kit Lens — Shutter 8K Only", specs: ["24.2MP APS-C sensor", "Shutter count ~8,200", "2 batteries + charger", "Sensor professionally cleaned"] },
  { match: /ps5|playstation|xbox|nintendo|switch|gaming/i, product: "Game Console", brand: "Sony", category: "Gaming", title: "PlayStation 5 Disc Edition 825GB + 2 Controllers — Mint", specs: ["Disc edition, 825GB", "2x DualSense controllers", "Dust-free, adult owned", "All cables + stand"] },
  { match: /sofa|couch|chair|table|desk|bed|furniture|ikea/i, product: "Sofa / Furniture", brand: "IKEA", category: "Home & Furniture", title: "Modern 3-Seater Fabric Sofa — Pet-Free Home, No Stains", specs: ["Solid hardwood frame", "Washable covers", "From pet & smoke-free home", "Can help disassemble"] },
  { match: /nike|adidas|jacket|coat|sneaker|dress|bag|zara|fashion/i, product: "Fashion Item", brand: "Nike", category: "Fashion", title: "Nike Sneakers EU 42 — Worn Twice, 100% Authentic + Box", specs: ["100% authentic, receipt available", "Worn twice indoors", "No creasing or defects", "Original box"] },
  { match: /bike|bicycle|trek|giant|scooter|e-?bike/i, product: "Bicycle", brand: "Trek", category: "Bikes & Scooters", title: "Trek Hybrid Bike Medium — New Tires, Fully Tuned", specs: ["New Kenda tires", "Full tune-up this month", "Shimano 21-speed", "Lock + lights included"] },
  { match: /dyson|vacuum|coffee|kitchen|air fryer|espresso/i, product: "Home Appliance", brand: "Dyson", category: "Appliances", title: "Dyson V11 Cordless Vacuum — New Filter, All Attachments", specs: ["New washable filter", "All 6 attachments", "60-min runtime", "Wall mount + charger"] },
  { match: /lego|toy|stroller|bike.*kid|ps4.*kid/i, product: "Kids Bundle", brand: "LEGO", category: "Toys & Kids", title: "LEGO Technic Bundle (3 Sets, Complete) — Sanitized", specs: ["3 complete sets with manuals", "All minifigs included", "Sanitized, smoke-free", "Sorted in storage box"] },
];

function hashStr(s: string) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return Math.abs(h);
}

export function identifyProduct(input: { fileName?: string; hint?: string; category?: string }) {
  const hint = `${input.fileName ?? ""} ${input.hint ?? ""}`.trim();
  const category = input.category || "Other";
  // The fallback must never invent a model, serial number, battery health,
  // accessories, authenticity, measurements, or other seller facts.
  return {
    product: hint || "Pre-loved item",
    brand: "",
    category,
    title: hint ? `${hint.slice(0, 70)} — Used Item` : "Used Item — Details to confirm",
    specs: ["Verify model/specifications from the item", "Confirm condition and included accessories", "Add measurements or serial/model details if visible"],
    match: /.*/ as RegExp,
  };
}

export function analyzePhoto(input: { fileName?: string; hint?: string; category?: string; imageCount?: number }) {
  const found = identifyProduct(input);
  const imageCount = input.imageCount ?? 0;
  return {
    product: found.product, brand: found.brand, category: found.category,
    confidence: 0,
    detectedCondition: "Needs seller confirmation",
    titleDraft: found.title, tags: [], specs: found.specs,
    photoTips: imageCount < 3
      ? ["Add several clear angles", "Photograph labels/model numbers when present", "Show defects honestly"]
      : ["Keep the main photo clear", "Include close-ups of defects and labels", "Avoid misleading filters"],
  };
}

export function generateListing(input: {
  productHint: string; category?: string; condition?: Condition | string; brand?: string; extras?: string; marketplace?: string;
}) {
  const product = input.productHint.trim() || "Used item";
  const category = input.category || "Other";
  const brand = input.brand?.trim() || "";
  const condition = input.condition || "Needs seller confirmation";
  const facts = input.extras?.trim() || "";
  const title = `${brand ? `${brand} ` : ""}${product} — ${condition}`.slice(0, 80);
  const description = [
    `FOR SALE: ${brand ? `${brand} ` : ""}${product}`,
    `Category: ${category}`,
    `Condition: ${condition} (please verify and edit before publishing)`,
    facts ? `Seller-provided details: ${facts}` : "Seller details: add model, specifications, included accessories, measurements and any defects before publishing.",
    "This draft intentionally avoids claiming facts that were not supplied by the seller.",
  ].join("\n\n");
  return {
    title,
    description,
    keywords: [category, brand].filter(Boolean),
  };
}

export function estimatePrice(input: { category?: string; condition?: string; originalPriceCents?: number | null; hint?: string }) {
  const category = input.category || identifyProduct({ hint: input.hint ?? "" }).category;
  const base = CATEGORY_BASELINE[category] ?? CATEGORY_BASELINE.Other;
  const cond = (input.condition as Condition) || "Good";
  const mult = CONDITION_MULT[cond] ?? 0.6;
  const seed = hashStr(`${input.hint ?? category}${cond}`) % 20; // 0..19 deterministic jitter

  let mid: number;
  if (input.originalPriceCents && input.originalPriceCents > 0) {
    mid = Math.round(input.originalPriceCents * mult);
  } else {
    mid = Math.round(((base.low + base.high) / 2) * (0.55 + mult * 0.55));
  }
  mid = Math.round(mid * (0.92 + seed / 100));
  // round to nice .99 / whole
  const roundNice = (v: number) => Math.max(100, Math.round(v / 100) * 100);
  const low = roundNice(mid * 0.88);
  const high = roundNice(mid * 1.12);
  const suggested = roundNice(mid);
  const sellFast = roundNice(mid * 0.82);
  return {
    low, high, suggested, sellFast, category,
    confidence: 0,
    reasoning: [
      `Baseline for "${category}" in "${cond}" condition is ${fmt(low)}–${fmt(high)}.`,
      input.originalPriceCents ? `Applied ${Math.round(mult * 100)}% retention of original retail ${fmt(input.originalPriceCents)}.` : `No retail price given — used an internal category heuristic, not live-market data.`,
      `Use ${fmt(suggested)} as the suggested asking price and ${fmt(sellFast)} as a lower-price scenario. Actual selling time varies by item and marketplace.`,
      "Tip: test a simple, easy-to-read price and compare buyer response over time.",
    ],
  };
}

function fmt(cents: number) {
  return `$${(cents / 100).toLocaleString("en-US", { maximumFractionDigits: 0 })}`;
}

export function qualityScore(input: {
  title: string; description: string; priceCents: number; imageCount: number;
  category?: string; brand?: string; condition?: string; keywords?: string[];
}) {
  const checks: Array<{ label: string; passed: boolean; weight: number; fix: string }> = [
    { label: "Title 30–80 chars with condition keyword", passed: input.title.length >= 30 && input.title.length <= 80, weight: 15, fix: "Rewrite the title to 40–60 chars and include the condition (e.g. 'Like New', 'Excellent')." },
    { label: "Title mentions brand/model", passed: input.title.split(" ").length >= 4, weight: 10, fix: "Add brand + model to the title — buyers search by model name." },
    { label: "Description 150+ chars", passed: (input.description || "").length >= 150, weight: 15, fix: "Expand the description: condition, what's included, why you're selling." },
    { label: "Description has condition + included items", passed: /condition|include|box|charger|accessor/i.test(input.description || ""), weight: 10, fix: "Add a 'What's included' bullet list to the description." },
    { label: "Competitive price set", passed: input.priceCents > 0, weight: 10, fix: "Set a clear asking price so buyers can evaluate the listing." },
    { label: "4+ photos", passed: input.imageCount >= 4, weight: 15, fix: "Upload at least 4 photos: front, back, detail, and item in use." },
    { label: "Category + condition selected", passed: Boolean(input.category && input.category !== "Other") && Boolean(input.condition), weight: 10, fix: "Pick a specific category and honest condition." },
    { label: "5+ search keywords", passed: (input.keywords?.length ?? 0) >= 3 || (input.description?.length ?? 0) > 300, weight: 10, fix: "Add keywords buyers search: unlocked, original box, tested, smoke-free." },
    { label: "Primary photo set", passed: input.imageCount >= 1, weight: 5, fix: "Set a clear cover photo that shows the item without misleading edits." },
  ];
  const score = checks.reduce((s, c) => s + (c.passed ? c.weight : 0), 0);
  return { score, checks, grade: score >= 80 ? "Excellent" : score >= 60 ? "Good" : score >= 40 ? "Needs work" : "Poor" };
}

export function optimizeForMarketplace(marketplaceId: string, listing: { title: string; description: string; priceCents: number; imageCount: number }) {
  const guides: Record<string, { title: string; checklist: Array<{ task: string; done: boolean; why: string }>; proTip: string }> = {
    ebay: {
      title: "eBay optimization",
      checklist: [
        { task: `Title uses 60–80 chars (now ${listing.title.length})`, done: listing.title.length >= 50, why: "Relevant title words help buyers understand and search for the item" },
        { task: "Item specifics filled (brand, model, condition)", done: listing.title.split(" ").length >= 4, why: "Specific item details can make marketplace filters and buyer evaluation easier" },
        { task: "Free returns or clear return note in description", done: /return|refund/i.test(listing.description), why: "A clear return policy can improve buyer confidence when applicable" },
        { task: "6+ photos incl. flaws close-up", done: listing.imageCount >= 4, why: "Additional clear photos can help buyers inspect the item" },
        { task: "Buy It Now + Best Offer enabled", done: listing.priceCents > 0, why: "Best Offer captures hagglers without losing price" },
      ],
      proTip: "Use the marketplace tools and policies currently available to you; test timing rather than assuming a universal peak.",
    },
    facebook: {
      title: "Facebook Marketplace optimization",
      checklist: [
        { task: "Cover photo is bright, no collage", done: listing.imageCount >= 1, why: "FB crops collages badly in feed" },
        { task: "Price ends in 0/5/9", done: listing.priceCents % 100 === 0 || listing.priceCents % 100 === 900, why: "A simple, readable price is easier for buyers to compare" },
        { task: "Location + pickup/delivery in description", done: /pickup|deliver|ship|location/i.test(listing.description), why: "Location and pickup/delivery details answer a common buyer question" },
        { task: "Reply-time promise in description", done: /reply|message|hour/i.test(listing.description), why: "A truthful response-time note can set buyer expectations" },
        { task: "Cross-post to 3+ buy/sell groups", done: false, why: "Cross-posting to relevant buy/sell groups can increase exposure" },
      ],
      proTip: "Refresh listings only according to the marketplace rules, and respond promptly when possible.",
    },
    craigslist: {
      title: "Craigslist optimization",
      checklist: [
        { task: "Short punchy title (<60 chars)", done: listing.title.length <= 70, why: "CL truncates long titles in list view" },
        { task: "Price in title or first line", done: listing.priceCents > 0, why: "CL buyers filter by price first" },
        { task: "Contact preference stated", done: /call|text|message|email/i.test(listing.description), why: "Cuts spam and speeds real inquiries" },
        { task: "No external links (flag risk)", done: !/http/i.test(listing.description), why: "Links trigger auto-flagging" },
      ],
      proTip: "Post Tue–Thu mornings and include nearest cross-streets (not exact address) for local trust.",
    },
    amazon: {
      title: "Amazon Renewed optimization",
      checklist: [
        { task: "Condition notes mention testing + grading", done: /test|excellent|grade/i.test(listing.description), why: "Required for Renewed eligibility" },
        { task: "No lifestyle claims ('best', 'amazing')", done: !/amazing|best ever/i.test(listing.description), why: "Factual descriptions are safer than unsupported marketing claims" },
        { task: "Bullet specs included", done: /•|-/.test(listing.description), why: "Bullets make specifications easier to scan" },
      ],
      proTip: "Only add warranty or guarantee terms that you actually provide and that the marketplace permits.",
    },
    noon: {
      title: "noon optimization",
      checklist: [
        { task: "Bilingual title (EN + AR keywords)", done: /[؀-ۿ]/.test(listing.title + listing.description), why: "Arabic keywords can help when your target audience searches in Arabic" },
        { task: "White-background main image", done: listing.imageCount >= 1, why: "A clean main image makes the item easier to inspect" },
        { task: "Warranty/return line present", done: /warranty|return|guarantee/i.test(listing.description), why: "Clear warranty and return terms can reduce buyer uncertainty when applicable" },
      ],
      proTip: "List during White/Yellow Friday prep windows and enable noon Express if you can ship fast.",
    },
    opensooq: {
      title: "OpenSooq optimization",
      checklist: [
        { task: "Call-to-action in first line", done: /call|whatsapp|message/i.test(listing.description), why: "A clear contact call-to-action makes the next step obvious" },
        { task: "City + neighborhood mentioned", done: /pickup|deliver|amman|dubai|riyadh|cairo/i.test(listing.description), why: "Local buyers filter by area" },
        { task: "Arabic summary included", done: /[؀-ۿ]/.test(listing.description), why: "Can make the listing easier to understand for Arabic-speaking buyers" },
      ],
      proTip: "Consider a short featured placement if the marketplace offers it and the expected extra exposure justifies the fee.",
    },
    dubizzle: {
      title: "dubizzle optimization",
      checklist: [
        { task: "Verified-number note", done: /verif|call|whatsapp/i.test(listing.description), why: "Clear verification and contact information can improve buyer confidence" },
        { task: "4+ photos with honest wear shot", done: listing.imageCount >= 3, why: "Showing defects clearly reduces surprises for buyers" },
        { task: "Final price vs negotiable stated", done: /final|negot|firm|offer/i.test(listing.description), why: "Makes the negotiation terms clear" },
      ],
      proTip: "Use a clear, truthful call-to-action such as asking buyers to message for availability.",
    },
    depop: {
      title: "Depop / Vinted optimization",
      checklist: [
        { task: "Lifestyle cover photo (worn/styled)", done: listing.imageCount >= 2, why: "Lifestyle photos can help buyers understand how the item looks in use" },
        { task: "Measurements in description", done: /cm|inch|size|measure/i.test(listing.description), why: "Measurements reduce avoidable sizing questions" },
        { task: "Hashtag keywords present", done: /#/.test(listing.description) || listing.description.length > 200, why: "Relevant keywords can help buyers find the item" },
      ],
      proTip: "Refresh the listing when the marketplace permits it, and keep the item details accurate.",
    },
  };
  return guides[marketplaceId] ?? guides.facebook;
}

export function negotiateReply(input: { buyerMessage: string; askingCents: number; offerCents?: number | null; tone?: string; listingTitle?: string }) {
  const offer = input.offerCents ?? null;
  const tone = input.tone || "friendly";
  const ratio = offer && input.askingCents ? offer / input.askingCents : 1;
  const verdict = !offer ? "no-offer" : ratio >= 0.95 ? "accept" : ratio >= 0.8 ? "counter-small" : ratio >= 0.6 ? "counter-firm" : "decline-soft";
  const counter = offer ? Math.round((offer + input.askingCents) / 2 / 100) * 100 : input.askingCents;

  const openers: Record<string, string> = {
    friendly: "Hi there! Thanks so much for your interest",
    firm: "Hi, thanks for reaching out",
    professional: "Hello, thank you for your inquiry",
    playful: "Hey! Great taste 😄",
  };
  const o = openers[tone] ?? openers.friendly;

  let reply = "";
  if (verdict === "no-offer") reply = `${o} — yes, "${input.listingTitle || "the item"}" is still available! It's ${fmt(input.askingCents)} and it's in great shape. Want to come see it today? I can do pickup or meet halfway.`;
  else if (verdict === "accept") reply = `${o}! ${fmt(offer!)} works for me — it's yours if you can pick up today/tomorrow. I'll hold it for you with a small deposit. When suits you?`;
  else if (verdict === "counter-small") reply = `${o}! I can meet you in the middle at ${fmt(counter)} — it's already priced below market and includes all accessories. If that works, it's yours today!`;
  else if (verdict === "counter-firm") reply = `${o}. I appreciate the offer of ${fmt(offer!)}, but I can't go that low — similar ones sell for ${fmt(input.askingCents)}+. Best I can do is ${fmt(counter)}. Let me know!`;
  else reply = `${o}. Thanks for the offer, but ${fmt(offer!)} is too low for me right now — I'll have to pass. Happy to keep you in mind if the price drops. Good luck with your search!`;

  const tips = [
    ratio < 0.6 && offer ? "Low offer detected. Stay polite and decide on a minimum acceptable price before countering." : "Offer is within haggling range. Always counter once before accepting.",
    "Never say 'need gone ASAP' — urgency language invites lower offers.",
    "Reply promptly when possible; fast responses generally reduce buyer drop-off.",
  ];
  return { reply, verdict, counterCents: counter, ratio, tips };
}
