export function text(value: unknown, max: number, fallback = "") {
  if (typeof value !== "string") return fallback;
  return value.trim().slice(0, max);
}

export function email(value: unknown) {
  const v = text(value, 254).toLowerCase();
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) ? v : null;
}

export function integer(value: unknown, min = 0, max = Number.MAX_SAFE_INTEGER) {
  const n = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(n) || !Number.isInteger(n) || n < min || n > max) return null;
  return n;
}

export function imageDataUrl(value: unknown) {
  if (typeof value !== "string") return null;
  if (/^data:image\/(jpeg|jpg|png|webp);base64,[a-z0-9+/=]+$/i.test(value)) return value.length <= 8_000_000 ? value : null;
  try {
    const url = new URL(value);
    return url.protocol === "https:" && url.href.length <= 2_000 ? url.href : null;
  } catch { return null; }
}


export function password(value: unknown) {
  if (typeof value !== "string") return null;
  return value.length >= 8 && value.length <= 128 ? value : null;
}

export function moneyCents(value: unknown, max = 100_000_000) {
  return integer(value, 0, max);
}

export function enumValue<T extends string>(value: unknown, allowed: readonly T[], fallback: T): T {
  return typeof value === "string" && allowed.includes(value as T) ? value as T : fallback;
}

export function stringArray(value: unknown, maxItems = 20, maxItemLength = 100) {
  if (!Array.isArray(value)) return [];
  return value.slice(0, maxItems).map((v) => text(v, maxItemLength)).filter(Boolean);
}

export function safeImageUrl(value: unknown) {
  if (typeof value !== "string") return null;
  try {
    const url = new URL(value);
    if (url.protocol !== "https:") return null;
    return url.href.length <= 2_000 ? url.href : null;
  } catch {
    return null;
  }
}
