import { db } from "@/db";
import { aiUsage, users } from "@/db/schema";
import { eq, and, sql } from "drizzle-orm";

export const FREE_AI_LIMIT = 10;
export const PRO_AI_LIMIT = 200;

export function currentBillingMonth() {
  return new Date().toISOString().slice(0, 7);
}

export async function getPlanUsage(userId: string) {
  const user = (await db.select({ plan: users.plan, subscriptionStatus: users.subscriptionStatus }).from(users).where(eq(users.id, userId)).limit(1))[0];
  const month = currentBillingMonth();
  const usage = (await db.select().from(aiUsage).where(and(eq(aiUsage.userId, userId), eq(aiUsage.month, month))).limit(1))[0];
  const proStatuses = new Set(["active", "on_trial"]);
  const limit = user?.plan === "pro" && proStatuses.has(user.subscriptionStatus) ? PRO_AI_LIMIT : FREE_AI_LIMIT;
  return { plan: user?.plan ?? "free", status: user?.subscriptionStatus ?? "inactive", used: usage?.count ?? 0, limit, remaining: Math.max(0, limit - (usage?.count ?? 0)), month };
}

export async function consumeAiCredit(userId: string) {
  const usage = await getPlanUsage(userId);
  if (usage.used >= usage.limit) return { allowed: false, ...usage };

  // One SQL statement makes the quota check + increment atomic. Concurrent
  // requests cannot consume more than the configured monthly limit.
  const result = await db.insert(aiUsage).values({
    userId, month: usage.month, count: 1,
  }).onConflictDoUpdate({
    target: [aiUsage.userId, aiUsage.month],
    set: { count: sql`${aiUsage.count} + 1` },
    where: sql`${aiUsage.count} < ${usage.limit}`,
  }).returning({ count: aiUsage.count });

  const used = result[0]?.count;
  if (!used || used > usage.limit) {
    return { allowed: false, ...usage, used: Math.min(usage.used, usage.limit), remaining: 0 };
  }
  return { allowed: true, ...usage, used, remaining: Math.max(0, usage.limit - used) };
}
