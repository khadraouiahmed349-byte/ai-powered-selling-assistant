type JsonSchema = Record<string, unknown>;

type AiImage = { url: string; detail?: "low" | "high" | "auto" };

const OPENAI_URL = "https://api.openai.com/v1/responses";
const MODEL = process.env.OPENAI_MODEL || "gpt-5.6-luna";

function requireKey() {
  const key = process.env.OPENAI_API_KEY;
  if (!key) throw new Error("OPENAI_API_KEY is not configured");
  return key;
}

export async function openAIJson(args: {
  prompt: string;
  images?: AiImage[];
  schemaName: string;
  schema: JsonSchema;
  timeoutMs?: number;
}) {
  const key = requireKey();
  const content: Array<Record<string, unknown>> = [{ type: "input_text", text: args.prompt }];
  for (const image of (args.images ?? []).slice(0, 8)) content.push({ type: "input_image", image_url: image.url, detail: image.detail ?? "auto" });

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), args.timeoutMs ?? 45_000);
  try {
    const response = await fetch(OPENAI_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
      body: JSON.stringify({
        model: MODEL,
        store: false,
        input: [{ role: "user", content }],
        text: { format: { type: "json_schema", name: args.schemaName, strict: true, schema: args.schema } },
      }),
      signal: controller.signal,
      cache: "no-store",
    });
    const data = await response.json() as { output_text?: string; error?: { message?: string } };
    if (!response.ok) throw new Error(data.error?.message || `OpenAI request failed (${response.status})`);
    if (!data.output_text) throw new Error("OpenAI returned no structured output");
    return JSON.parse(data.output_text) as Record<string, unknown>;
  } finally {
    clearTimeout(timer);
  }
}
